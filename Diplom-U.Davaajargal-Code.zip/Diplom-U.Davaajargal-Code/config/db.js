const mongoose = require("mongoose");

const connectDB = async () => {
  const conn = await mongoose.connect(process.env.MONGODB_URI);
  console.log(`MongoDB holbogdloo: ${conn.connection.host}`);
};
// , {
//   useNewUrlParser: true, //uri iig parse hiih algoritm ashiglah
//   useCreateIndex: true, //
//   useFindAndModify: false,
//   useUnifiedTopology: true, //atlas deer cluster uusegse tsaanaa hed hedn host uusne. sever uudiig haih
// }
module.exports = connectDB;
