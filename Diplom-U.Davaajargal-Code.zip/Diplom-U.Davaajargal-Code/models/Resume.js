const mongoose = require("mongoose");

const ResumeScheme = new mongoose.Schema(
  {
    createUser: {
      type: mongoose.SchemaTypes.ObjectId,
      ref: "User",
    },
    photo: {
      type: String,
      default: "no-photo.jpg",
    },
    cv: {
      type: String,
      default: "no-cv",
    },
    general: {
      summary: {
        type: String,
        required: [true, "Та өөрийн тухай товч мэдээллээ оруулна уу."],
        trim: true,
        maxlength: [
          1000,
          "Та өөрийн тухай товч мэдээллээ 1000 тэмдэгтэд багтаан оруулж өгнө үү.",
        ],
        default: null,
      },
      lastname: {
        type: String,
        required: [true, "Овог нэрийг оруулна уу."],
        trim: true, //hooson zaig ustgah 2r talaas
        maxlength: [50, "Овог нэрийн урт дээд тал нь 50 тэмдэгт байх ёстой."],
        default: null,
      },
      firstname: {
        type: String,
        trim: true,
        required: [true, "Өөрийн нэрийг оруулна уу."],
        maxlength: [50, "Өөрийн нэрийн урт дээд тал нь 50 тэмдэгт байх ёстой."],
        default: null,
      },
      gender: {
        type: String,
        trim: true,
        enum: ["Эмэгтэй", "Эрэгтэй"],
        default: "----",
      },
      birthdate: {
        type: Date,
        required: [true, "Өөрийн төрсөн огноог оруулна уу."],
        default: null,
      },
      age: {
        type: Number,
        required: [true, "Өөрийн насыг оруулна уу."],
        default: null,
      },
      register: {
        type: String,
        trim: true,
        required: [true, "Өөрийн регистрийн дугаараа оруулна уу."],
        default: null,
      },
    },
    contact: {
      phone: {
        type: Number,
        required: true,
      },
      email: {
        type: String,
        required: true,
      },
      address: {
        type: String,
        required: true,
      },
    },
    desiredjob: {
      job: {
        type: mongoose.SchemaTypes.ObjectId,
        ref: "Career",
        required: true,
      },
      salary: {
        type: Number,
        trim: true,
        // required: true,
        default: null,
      },
      worktime: {
        type: String,
        // required: true,
        default: null,
      },
    },
    education: [
      {
        institution: {
          type: String,
          required: [
            true,
            "Боловсрол эзэмшсэн байгууллагын төрлийг оруулна уу.",
          ],
          enum: ["Ахлах сургууль", "Их сургууль", "Коллеж", "Сургалт"],
        },
        schoolName: {
          type: String,
          required: [
            true,
            "Боловсрол эзэмшсэн байгууллагын нэрийг оруулна уу.",
          ],
        },
        degree: {
          type: String,
          required: [true, "Боловсролын зэргийг оруулна уу."],
        },
        gpa: {
          type: Number,
          required: [true, "Голч дүнг оруулна уу."],
        },
        startDate: {
          type: String,
          required: [true, "Элссэн огноог оруулна уу."],
        },
        endDate: {
          type: String,
          required: [true, "Төгссөн огноог оруулна уу."],
        },
        location: {
          type: String,
          required: [
            true,
            "Боловсрол эзэмшсэн байгууллагын байршил оруулна уу.",
          ],
        },
        profession: {
          type: String,
          required: [true, "Мэргэжилээ оруулна уу."],
        },
      },
    ],
    experiences: [
      {
        position: {
          type: String,
          // required: [true, "Ажиллаж байсан албан тушаалаа оруулна уу."],
          default: null,
        },
        company: {
          type: String,
          // required: [true, "Ажиллаж байсан албан байгууллагаа оруулна уу."],
          default: null,
        },
        location: {
          type: String,
          default: null,
          // required: [
          // true,
          // "Ажиллаж байсан албан байгууллагын байршил оруулна уу.",
          // ],
        },
        startDate: {
          default: null,
          type: String,
          // required: [true, "Ажилд орсон огноог оруулна уу."],
        },
        endDate: {
          default: null,
          type: String,
          // required: [true, "Ажлаас гарсан огноог оруулна уу."],
        },
      },
    ],

    skills: [
      {
        name: {
          default: null,
          type: String,
          // required: true,
        },
        level: {
          type: String,
          default: null,
          enum: ["Анхан", "Дунд", "Ахисан"],
          // required: true,
        },
      },
    ],
    language: [
      {
        name: {
          default: null,
          type: String,
          // required: true,
        },
        level: {
          type: String,
          default: null,
          enum: ["Анхан", "Дунд", "Ахисан"],
          // required: true,
        },
      },
    ],
    family: [
      {
        name: {
          type: String,
          default: null,
          // required: true,
        },
        who: {
          type: String,
          default: null,
          // required: true,
        },
        age: {
          type: Number,
          default: null,
          // required: true,
        },
        positionF: {
          type: String,
          default: null,
        },
        phone: {
          type: Number,
          default: null,
        },
      },
    ],
    createdAt: {
      type: Date,
      default: Date.now,
    },
    updatedAt: {
      type: Date,
      default: null,
    },
  },
  {
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);
ResumeScheme.pre("save", async function (next) {
  //Нууц үг өөрчлөгдсөн эсэх
  if (!this.isModified("cv")) next();
});
// ResumeScheme.virtual("")

// ResumeScheme.statics.computeJobAllResume = async function (jobid) {
//   const obj = await this.aggregate([
//     { $match: { job: jobid } },
//     { $group: { _id: "$jobName", allResume: { $sum: 1 } } },
//   ]);

//   await this.model("Career").findByIdAndUpdate(jobid, {
//     resumes: obj[0].allResume,
//   });
//   return obj;
// };
// ResumeScheme.post("save", function () {
//   this.constructor.computeJobAllResume(this.jobName);
// });
// ResumeScheme.post("update", function () {
//   this.constructor.computeJobAllResume(this.jobName);
// });
module.exports = mongoose.model("Resume", ResumeScheme);
