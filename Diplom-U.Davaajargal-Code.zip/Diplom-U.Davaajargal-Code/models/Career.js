const mongoose = require("mongoose");

const CareerSchema = new mongoose.Schema(
  {
    createUser: {
      type: mongoose.SchemaTypes.ObjectId,
      ref: "User",
    },
    updateUser: {
      type: mongoose.SchemaTypes.ObjectId,
      ref: "User",
    },
    deleteUser: {
      type: mongoose.SchemaTypes.ObjectId,
      ref: "User",
    },
    name: {
      type: String,
      required: [true, "Ажлын нэрийг оруулна уу."],
      //unique: true,
      trim: true,
      maxlength: [50, "Ажлын нэрний урт дээд тал нь 50 тэмдэгт байх ёстой."],
    },
    skill: {
      type: [String],
      required: [true, "Ажлын байрны тавигдах шаардлагыг оруулна уу."],
      maxlength: [
        500,
        "Ажлын байрны тавигдах шаардлагын урт дээд тал нь 500 тэмдэгт байх ёстой.",
      ],
    },
    worktime: {
      type: String,
      required: [true, "Ажлын байрны төлөв оруулна уу."],
      maxlength: [
        50,
        "Ажлын байрны төлвийн урт дээд тал нь 50 тэмдэгт байх ёстой.",
      ],
    },
    createdAt: {
      type: Date,
      default: Date.now,
    },
    endDate: {
      type: Date,
      require: [true, "Хэднийг хүртэл анкет авах хугацааг оруулж өгнө үү."],
      // default: Date.now,
    },
  },
  {
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

// CareerScheme.pre("remove", async function (next) {
//   console.log("removing ...");
//   await this.model("Resume").deleteMany({ jobName: this._id });
// });

module.exports = mongoose.model("Career", CareerSchema);
