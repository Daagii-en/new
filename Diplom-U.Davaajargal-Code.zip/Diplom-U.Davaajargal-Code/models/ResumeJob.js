const mongoose = require("mongoose");

const ResumeJobScheme = new mongoose.Schema({
  createUser: {
    type: mongoose.SchemaTypes.ObjectId,
    unique: true,
    ref: "Resume",
  },
  deleteUser: {
    type: mongoose.SchemaTypes.ObjectId,
    unique: true,
    ref: "User",
  },
  jobId: {
    type: mongoose.SchemaTypes.ObjectId,
    ref: "Career",
    default: null,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});
module.exports = mongoose.model("ResumeJob", ResumeJobScheme);
