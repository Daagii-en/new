const express = require("express");
const {
  createResumeJob,
  deleteResumeJob,
  getResumeJob,
} = require("../controller/resumejob");
const { protect, authorize } = require("../middleware/protect.js");

const router = express.Router();

router.route("/").get(protect, authorize("admin"), getResumeJob);
router
  .route("/:userId")
  .post(protect, authorize("admin", "user"), createResumeJob)
  .delete(protect, authorize("admin"), deleteResumeJob);

module.exports = router;
