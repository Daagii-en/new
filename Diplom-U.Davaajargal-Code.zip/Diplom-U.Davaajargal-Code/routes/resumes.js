const express = require("express");
const {
  getResumes,
  createResume,
  updateResume,
  updateResumePhoto,
  getUserResumes,
  deleteResume,
} = require("../controller/resumes.js");
const { protect, authorize } = require("../middleware/protect.js");

const router = express.Router({ mergeParams: true });
//"/api/resumes"
router.route("/").get(protect, authorize("admin"), getResumes);

router
  .route("/:userId/data")
  .get(protect, authorize("admin", "user"), getUserResumes)
  .post(protect, authorize("admin", "user"), createResume)
  .put(protect, authorize("admin", "user"), updateResume)
  .delete(protect, authorize("admin", "user"), deleteResume);

router
  .route("/:userId/upload-photo")
  .put(protect, authorize("admin", "user"), updateResumePhoto);
// router.route("/:userId/data/update").put(updateResume);

module.exports = router;
