const express = require("express");
const {
  getCareers,
  getCareer,
  createCareer,
  deleteCareer,
  updateCareer,
} = require("../controller/careers.js");
const { protect, authorize } = require("../middleware/protect.js");

const router = express.Router({ mergeParams: true });

//api/careers/:careerId/resumes
// const { getCareerUserResumes } = require("../controller/resumes.js");
// router
//   .route("/:careerId/resumes")
//   .get(protect, authorize("admin"), getCareerUserResumes);

// const resumesRoutes = require("./resumes.js");
// router.use("/:careerId/resumes", resumesRoutes);

//"/api/v1/careers"
router
  .route("/")
  .get(getCareers)
  .post(protect, authorize("admin"), createCareer);
router
  .route("/:id")
  .get(getCareer)
  .put(protect, authorize("admin"), updateCareer)
  .delete(protect, authorize("admin"), deleteCareer);

module.exports = router;
