const express = require("express");
const {
  signUp,
  createUser,
  signIn,
  getUser,
  updateUser,
  updateUserPhoto,
  getUsers,
  deleteUser,
  forgotPassword,
  resetPassword,
  changePassword,
} = require("../controller/users");
const {
  getUserResumes,
  createResume,
  updateResume,
  deleteResume,
  updateResumePhoto,
} = require("../controller/resumes");

const { protect, authorize } = require("../middleware/protect.js");

const router = express.Router({ mergeParams: true });
//"/api/users"

router.route("/signup").post(signUp);
router.route("/signin").post(signIn);
router.route("/forgot-password").post(forgotPassword);
router.route("/reset-password/:resetToken").post(resetPassword);
router
  .route("/:id/change-password")
  .put(protect, authorize("admin", "user"), changePassword);
router
  .route("/")
  .get(protect, authorize("admin"), getUsers)
  .post(authorize("admin"), createUser);

router
  .route("/:id")
  .get(protect, authorize("admin", "user"), getUser)
  .put(updateUser)
  .delete(deleteUser);
router
  .route("/:id/photo")
  .put(protect, authorize("admin", "user"), updateUserPhoto);
router
  .route("/:userId/data")
  .get(protect, authorize("admin", "user"), getUserResumes)
  .post(protect, authorize("admin", "user"), createResume)
  .put(protect, authorize("admin", "user"), updateResume)
  .delete(protect, authorize("admin", "user"), deleteResume);

router
  .route("/:userId/upload-photo")
  .put(protect, authorize("admin", "user"), updateResumePhoto);

module.exports = router;
