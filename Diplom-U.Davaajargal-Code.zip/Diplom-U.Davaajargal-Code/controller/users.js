const User = require("../models/User");
const MyError = require("../utils/myError");
const asyncHandler = require("express-async-handler");
const paginate = require("../utils/paginate");
const sendEmail = require("../utils/email");
const crypto = require("crypto");
const path = require("path");
//signup hiih
exports.signUp = asyncHandler(async (req, res, next) => {
  const user = await User.create(req.body);

  const token = user.getJsonWebToken();

  res.status(200).json({
    success: true,
    user: user,
    token,
  });
});
//signin hiih
exports.signIn = asyncHandler(async (req, res, next) => {
  //Оролтыг шалгана.
  const { email, password } = req.body;
  if (!email || !password) {
    throw new MyError("Имэйл болон нууц үгээ дамжуулна уу.", 400);
  }
  //Тухайн хэрэглэгчийг хайх
  const user = await User.findOne({ email }).select("+password");

  if (!user) {
    throw new MyError("Имэйл болон нууц үгээ зөв оруулна уу.", 401);
  }

  const ok = await user.checkPassword(password);

  if (!ok) {
    throw new MyError("Имэйл болон нууц үгээ зөв оруулна уу.", 401);
  }
  const token = user.getJsonWebToken();
  // const CookieOptions = {
  //   expires: new Date(Data.now() + 30 * 24 * 60 * 60 * 1000),
  // };
  res.status(200).json({
    success: true,
    login: true,
    user: user,
    token,
  });
});
exports.getUsers = asyncHandler(async (req, res, next) => {
  const select = req.query.select;
  const sort = req.query.sort;
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 50;
  //delete req.query.limit;
  ["select", "sort", "page", "limit"].forEach((el) => delete req.query[el]);
  //Pagination
  const pagination = await paginate(page, limit, User);

  const users = await User.find(req.query, select)
    .sort(sort)
    .skip(pagination.start - 1)
    .limit(limit);
  //middleware
  res.status(200).json({
    success: true,
    data: users,
    pagination,
  });
});
exports.getUser = asyncHandler(async (req, res, next) => {
  const user = await User.findById(req.params.id);
  if (!user) {
    throw new MyError(`${req.params.id} ID-тэй хэрэглэгч байхгүй.`, 400);
  }
  res.status(200).json({
    success: true,
    data: user,
  });
});

exports.createUser = asyncHandler(async (req, res, next) => {
  const user = await User.create(req.body);

  // const createUser = user._id;
  // const resume = await Resume.create(createUser);

  res.status(200).json({
    success: true,
    data: user,
  });
});

exports.updateUser = asyncHandler(async (req, res, next) => {
  // req.body.updateUser = req.userId;
  const user = await User.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true, //models dotorh ugugdliin shalgaltiig hiih
  });
  if (!user) {
    throw (new MyError(req.params.id) + "ID-тэй хэрэглэгч байхгүй.", 400);
  }

  res.status(200).json({
    success: true,
    data: user,
  });
});
exports.updateUserPhoto = asyncHandler(async (req, res, next) => {
  const user = await User.findById(req.params.id);
  // console.log("updateUser", user);
  if (!user) {
    throw new MyError(req.params.id + " ID-тэй хэрэглэгч байхгүй.");
  }
  //image upload
  console.log("req.files: ", req.files);
  const file = req.files.file;
  if (!file.mimetype.startsWith("image")) {
    throw new MyError("Та зураг upload хийнэ үү.", 400);
  }

  if (file.size > process.env.MAX_UPLOAD_FILE_SIZE) {
    throw new MyError("Та зурагны хэмжээ хэтэрсэн байна.", 400);
  }
  // res.status(200).json({
  //   success: true,
  //   data: resume,
  // });
  file.name = `userphoto_${req.params.id}${path.parse(file.name).ext}`;
  console.log("--->", file.name);
  file.mv(`${process.env.FILE_UPLOAD_PATH}/${file.name}`, (err) => {
    if (err) {
      throw new MyError(
        "Файл хуулах явцад алдаа гарлаа. Алдаа " + err.message,
        400
      );
    }
    console.log("file name " + file.name);
    user.photo = file.name;
    user.save();
    // resume = await Resume.findOneAndUpdate({
    //   createUser: req.params.userId,
    // },resume.photo);
    //resume = await resume.save();

    // resume.updateMany({ photo: file.name });

    res.status(200).json({
      success: true,
      data: { name: file.name, path: `/${file.name}` },
    });
  });

  // console.log(file.name);
});
exports.deleteUser = asyncHandler(async (req, res, next) => {
  // req.body.deleteUser = req.userId;
  const user = await User.findByIdAndDelete(req.params.id);
  if (!user) {
    throw (new MyError(req.params.id) + "ID-тэй хэрэглэгч байхгүй.", 400);
  }

  res.status(200).json({
    success: true,
    data: user,
  });
});

exports.forgotPassword = asyncHandler(async (req, res, next) => {
  if (!req.body.email) {
    throw new MyError(`Та нууц үг сэргээх имэйл хаягаа дамжуулна уу.`, 400);
  }
  const user = await User.findOne({ email: req.body.email });
  if (!user) {
    throw new MyError(req.body.email + ` имэйлтэй хэрэглэгч олдсонгүй!`, 400);
  }

  const resetToken = user.generatePasswordChangeToken();
  user.save();
  // await user.save({validateBeforeSave:false})

  //Имэйл илгээх
  const link = `http://localhost:3000/changepassword/${resetToken}`;
  const message = `Сайн байна уу<br>Та нууц үгээ солих хүсэлт илгээлээ.<br> Нууц үгээ доорхи линк дээр дарж солино уу:<br><br><a target="_blank" href="${link}">${link}</a><br><br>Өдрийг сайхан өнгөхүүлээрэй!`;
  const info = await sendEmail({
    email: user.email,
    subject: "Нууц үг өөрчлөх хүсэлт.",
    message,
  });

  res.status(200).json({
    success: true,
    resetToken,
  });
});

exports.resetPassword = asyncHandler(async (req, res, next) => {
  if (!req.body.resetToken || !req.body.password) {
    throw new MyError(`Та токен болон нууц үгээ дамжуулна уу.`, 400);
  }

  const encrypted = crypto
    .createHash("sha256")
    .update(req.body.resetToken)
    .digest("hex");

  const user = await User.findOne({
    resetPasswordToken: encrypted,
    resetPasswordExpire: { $gt: Date.now() },
  });
  if (!user) {
    throw new MyError(` Хүчингүй токен байна.!`, 400);
  }

  user.password = req.body.password;
  user.resetPasswordToken = undefined;
  user.resetPasswordExpire = undefined;
  await user.save();

  const token = user.getJsonWebToken();

  res.status(200).json({
    success: true,
    token,
    user: user,
  });
});

exports.changePassword = asyncHandler(async (req, res, next) => {
  const { password, newPassword } = req.body;
  if (!newPassword || !password) {
    throw new MyError("нууц үгээ дамжуулна уу.", 400);
  }
  //Тухайн хэрэглэгчийг хайх
  const user = await User.findById(req.params.id).select("+password");

  if (!user) {
    throw new MyError("Хэрэглэгч олдсонгүй.", 401);
  }

  const ok = await user.checkPassword(password);

  if (!ok) {
    throw new MyError("Нууц үгээ зөв оруулна уу.", 401);
  }

  user.password = req.body.newPassword;
  await user.save();

  // const token = user.getJsonWebToken();

  res.status(200).json({
    success: true,
    // token,¿\
    user: user,
  });
});
