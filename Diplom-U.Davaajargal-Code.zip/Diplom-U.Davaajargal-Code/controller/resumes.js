const Resume = require("../models/Resume");
const path = require("path");
const User = require("../models/User");
const MyError = require("../utils/myError");
const paginate = require("../utils/paginate");

const asyncHandler = require("../middleware/asyncHandler");
const { createUser } = require("./users");

//api/v1/user/:userId/resume
//api/v1/resume/:userId/data
exports.getResumes = asyncHandler(async (req, res, next) => {
  const select = req.query.select;
  const sort = req.query.sort;
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 50;
  //delete req.query.limit;
  ["select", "sort", "page", "limit"].forEach((el) => delete req.query[el]);

  //Pagination
  const pagination = await paginate(page, limit, Resume);

  const resumes = await Resume.find(req.query, select)
    .populate("createUser")
    .populate("desiredjob.job")
    .sort(sort)
    .skip(pagination.start - 1)
    .limit(limit);

  if (!resumes) {
    throw new MyError("Одоогоор хэрэглэгчийн анкет байхгүй байна.");
  }
  res.status(200).json({
    success: true,
    data: resumes,
    pagination,
  });
});

exports.getUserResumes = asyncHandler(async (req, res, next) => {
  // req.query.createUser = req.userId;
  const resumes = await Resume.findOne({
    createUser: req.params.userId,
  })
    .populate("createUser")
    .populate("desiredjob.job");
  // console.log(resumes);
  if (!resumes) {
    res.status(200).json({
      success: true,
      data: null,
    });
    // throw new MyError(
    //   req.params.id + "ID-тэй хэрэглэгчийн анкет байхгүй байна."
    // );
  }

  res.status(200).json({
    success: true,
    data: resumes,
  });
});

// //api/careers/:careerID/resumes
// exports.getCareerUserResumes = asyncHandler(async (req, res, next) => {
//   const select = req.query.select;
//   const sort = req.query.sort;
//   const page = parseInt(req.query.page) || 1;
//   const limit = parseInt(req.query.limit) || 5;
//   //delete req.query.limit;
//   ["select", "sort", "page", "limit"].forEach((el) => delete req.query[el]);

//   //Pagination
//   const pagination = await paginate(page, limit, Resume);

//   //req.query, select
//   const resumes = await Resume.find(
//     { ...req.query, jobName : req.params.careerId },
//     select
//   )
//     .sort(sort)
//     .skip(pagination.start - 1)
//     .limit(limit);

//   if (!resumes) {
//     throw new MyError(req.params.id + "ID-тэй ажлын анкет байхгүй байна.");
//   }

//   res.status(200).json({
//     success: true,
//     data: resumes,
//     pagination,
//   });
// });

exports.createResume = asyncHandler(async (req, res, next) => {
  // const user = await User.findById(req.body.user);
  // if (!user) {
  //   throw new MyError(req.body.user + " ID-тай хэрэглэгч байхгүй байна.");
  // }
  req.body.createUser = req.userId;
  const resume = await Resume.create(req.body);

  res.status(200).json({
    success: true,
    data: resume,
    whoResume: req.body.createUser,
  });
});

exports.deleteResume = asyncHandler(async (req, res, next) => {
  const resume = await Resume.findOneAndDelete({
    createUser: req.params.userId,
  });
  if (!resume) {
    return res.status(400).json({
      success: false,
      error: `${req.params.userId} ID-тэй хэрэглэгчийн өгөгдөл байхгүй.`,
    });
  }
  console.log("=>: ", resume);
  res.status(200).json({
    success: true,
    data: resume,
  });
});

exports.updateResume = asyncHandler(async (req, res, next) => {
  const resume = await Resume.findOneAndUpdate(
    {
      createUser: req.params.userId,
    },
    req.body,
    {
      new: true,
      runValidators: true,
    }
  );

  if (!resume) {
    return res.status(400).json({
      success: false,
      error: `${req.params.userId} ID-тэй хэрэглэгчийн өгөгдөл байхгүй.`,
    });
  }

  resume = req.res.status(200).json({
    success: true,
    data: resume,
  });
});

// PUT: api/resume/:userId/photo
exports.updateResumePhoto = asyncHandler(async (req, res, next) => {
  const resume = await Resume.find({
    createUser: req.params.userId,
  });

  if (!resume) {
    throw new MyError(
      req.params.userId + " ID-тэй хэрэглэгчийн өгөгдөл байхгүй."
    );
  }
  //image upload
  console.log("req.files-==>", req.files);
  const file = req.files.file;
  if (!file.mimetype.startsWith("application/pdf")) {
    throw new MyError("Та pdf файл upload хийнэ үү.", 400);
  }

  if (file.size > process.env.MAX_UPLOAD_FILE_SIZE) {
    throw new MyError("Таны файлын хэмжээ хэтэрсэн байна.", 400);
  }
  // res.status(200).json({
  //   success: true,
  //   data: resume,
  // });
  file.name = `cv_${req.params.userId}${path.parse(file.name).ext}`;

  file.mv(`${process.env.FILE_UPLOAD_CV_PATH}/${file.name}`, (err) => {
    if (err) {
      throw new MyError(
        "Файл хуулах явцад алдаа гарлаа. Алдаа " + err.message,
        400
      );
    }
    console.log("file name " + file.name);
    resume.cv = file.name;
    resume.save();
    // resume = await Resume.findOneAndUpdate({
    //   createUser: req.params.userId,
    // },resume.photo);
    //resume = await resume.save();

    // resume.updateMany({ photo: file.name });

    res.status(200).json({
      success: true,
      data: { name: file.name, path: `/${file.name}` },
    });
  });

  // console.log(file.name);
});
