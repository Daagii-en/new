const Career = require("../models/Career");
const MyError = require("../utils/myError");
// const asyncHandler = require("../middleware/asyncHandler");

const asyncHandler = require("express-async-handler");

const paginate = require("../utils/paginate");

exports.getCareers = asyncHandler(async (req, res, next) => {
  //Req хүсэлт дотор ирэх select йиг устгаад ирсэн талбаруудаар нь гаргаж харуулах боломж, мөн sort хийх
  const select = req.query.select;
  const sort = req.query.sort;
  const page = parseInt(req.query.page) || 1;
  const limit = parseInt(req.query.limit) || 100;
  //delete req.query.limit;
  ["select", "sort", "page", "limit"].forEach((el) => delete req.query[el]);

  //Pagination
  const pagination = await paginate(page, limit, Career);

  const careers = await Career.find(req.query, select)
    .sort(sort)
    .skip(pagination.start - 1)
    .limit(limit);
  //middleware
  res.status(200).json({
    success: true,
    data: careers,
    pagination,
  });
});

exports.getCareer = asyncHandler(async (req, res, next) => {
  const career = await Career.findById(req.params.id);
  if (!career) {
    throw new MyError(`${req.params.id} ID-тэй ажил байхгүй.`, 400);
    // return res.status(400).json({
    //   success: false,
    //   error: `${req.params.id} ID-тэй ажил байхгүй.`,
    // });
  }
  res.status(200).json({
    success: true,
    data: career,
  });
});
exports.createCareer = asyncHandler(async (req, res, next) => {
  console.log("data: ", req.body);
  req.body.createUser = req.userId;
  const career = await Career.create(req.body);

  res.status(200).json({
    success: true,
    data: career,
  });
});
exports.updateCareer = asyncHandler(async (req, res, next) => {
  req.body.updateUser = req.userId;
  const career = await Career.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true, //models dotorh ugugdliin shalgaltiig hiih
  });
  if (!career) {
    return res.status(400).json({
      success: false,
      error: `${req.params.id} ID-тэй ажил байхгүй.`,
    });
  }

  res.status(200).json({
    success: true,
    data: career,
  });
});

exports.deleteCareer = asyncHandler(async (req, res, next) => {
  req.body.deleteUser = req.userId;
  const career = await Career.findByIdAndDelete(req.params.id);
  if (!career) {
    return res.status(400).json({
      success: false,
      error: `${req.params.id} ID-тэй ажил байхгүй.`,
    });
  }
  res.status(200).json({
    success: true,
    data: career,
  });
});
