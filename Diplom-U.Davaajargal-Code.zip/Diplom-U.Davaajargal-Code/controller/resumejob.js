const ResumeJob = require("../models/ResumeJob");
const MyError = require("../utils/myError");
const asyncHandler = require("../middleware/asyncHandler");
exports.createResumeJob = asyncHandler(async (req, res, next) => {
  console.log("data: ", req.body);
  req.body.createUser = req.userId;
  const resumejob = await ResumeJob.create(req.body);
  if (!resumejob) {
    return res.status(400).json({
      success: false,
      error: "Алдаа гарлаа",
    }); //throw new MyError("Алдаа гарлаа");
  }
  res.status(200).json({
    success: true,
    data: resumejob,
  });
});

exports.getResumeJob = asyncHandler(async (req, res, next) => {
  const resumejob = await ResumeJob.find(req.query);
  // const careers = await Career.find(req.query, select)
  //   .sort(sort)
  //   .skip(pagination.start - 1)
  //   .limit(limit);
  // //middleware
  if (!resumejob) {
    throw new MyError("Одоогоор хэрэглэгчийн анкет байхгүй байна.");
  }
  res.status(200).json({
    success: true,
    data: resumejob,
  });
});
exports.deleteResumeJob = asyncHandler(async (req, res, next) => {
  req.body.deleteUser = req.userId;
  const resumejob = await ResumeJob.findByIdAndDelete(req.params.id);
  if (!resumejob) {
    return res.status(400).json({
      success: false,
      error: `${req.params.id} ID-тай ажил байхгүй.`,
    });
  }
  res.status(200).json({
    success: true,
    data: resumejob,
  });
});
