import "./App.css";
import React, { Component } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Header from "./component/header/Header";
import Container from "./component/container/Container";
import Footer from "./component/footer/Footer";
import Career from "./component/career/Career";
import Login from "./component/login/Login";
import User from "./component/user/User";
import SignUp from "./component/login/SignUp";
import Admin from "./component/admin/Admin";
import axios from "axios";

export default class App extends Component {
  state = {
    token: null,
    name: null,
    role: null,
    id: null,
    email: null,
  };
  // const [login, setLogin] = useState(false);
  // const [token, setToken] = useState(null);

  handleLogin = (token, name, role, id, email) => {
    this.setState({
      token: token,
      name: name,
      role: role,
      id: id,
      email: email,
      userData: null,
      error: null,
    });

    localStorage.setItem("token", token);
    localStorage.setItem("role", role);
    localStorage.setItem("username", name);
    localStorage.setItem("userId", id);
    localStorage.setItem("email", email);
  };
  handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    localStorage.removeItem("username");
    localStorage.removeItem("userId");
    localStorage.removeItem("email");
    this.setState({ token: null, name: null, role: null, email: null });
  };
  componentDidMount = () => {
    if (!this.state.id) {
      axios
        .get(
          `http://localhost:8000/api/resumes/${localStorage.getItem(
            "userId"
          )}/data`,
          {
            headers: {
              authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          }
        )
        .then((result) => {
          // setUserData(result.data.data);
          this.setState({ userData: result.data.data });
          console.log("dtatat> ", result.data);
        })
        .catch((err) => {
          this.setState({ error: err.response });
          console.log("eeroror");
        });
    }
  };
  render() {
    return (
      <BrowserRouter>
        <div className="App">
          <Header />
          <div className="App container text-base">
            <Routes>
              <Route path="/" element={<Container />} />
              <Route
                path="/careers"
                element={
                  <>
                    <Career />
                    <Footer />
                  </>
                }
              />

              <Route
                path="/users/signin"
                element={<Login onLogin={this.handleLogin} />}
              />
              <Route
                path="/users/signup"
                element={<SignUp click={this.handleLogin} />}
              />
              <Route
                path="/users"
                element={
                  <User
                    onLogout={this.handleLogout}
                    userData={this.state.userData}
                  />
                }
              />
              <Route
                path="/admin"
                element={<Admin onLogout={this.handleLogout} />}
              />
            </Routes>
          </div>
        </div>
      </BrowserRouter>
    );
  }
}
