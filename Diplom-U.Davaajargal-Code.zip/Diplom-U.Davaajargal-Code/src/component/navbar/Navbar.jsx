import React from "react";
import { Link } from "react-scroll/modules";
import { Link as LinkRoute } from "react-router-dom";
import { Divider } from "@mui/material";
const Navbar = ({ click }) => {
  return (
    <div
      className="absolute z-10 font-semibold w-screen flex justify-end pr-10  bg-white "
      // role="menu"
      // aria-orientation="vertical"
      // aria-labelledby="menu-button"
    >
      <ul className=" items-center space-y-2 ">
        <li>
          <Link
            to="about"
            spy={true}
            smooth={true}
            offset={100}
            duration={1000}
            onClick={click}
            className=" w-full inline-block no-underline transition  ease-in-out hover:text-indigo-900 transform  hover:scale-100 font-semibold  lg:-ml-2 cursor-pointer "
          >
            <LinkRoute to="/">Бидний тухай</LinkRoute>
          </Link>
        </li>
        <Divider />
        <li>
          <Link
            to="team"
            spy={true}
            smooth={true}
            offset={100}
            duration={1000}
            onClick={click}
            className=" w-full inline-block no-underline transition ease-in-out hover:text-indigo-900 transform hover:scale-95 font-semibold cursor-pointer  lg:-ml-2"
          >
            <LinkRoute to="/">Манай баг</LinkRoute>
          </Link>
        </li>
        <Divider />
        <li>
          <Link
            to="partner"
            spy={true}
            smooth={true}
            offset={100}
            duration={1000}
            onClick={click}
            className=" w-full inline-block no-underline transition ease-in-out hover:text-indigo-900 transform hover:scale-95 font-semibold  cursor-pointer lg:-ml-2"
          >
            <LinkRoute to="/">Хамтрагч</LinkRoute>
          </Link>
        </li>
        <Divider />
        <li>
          <Link
            to="contact"
            spy={true}
            smooth={true}
            offset={100}
            duration={1000}
            onClick={click}
            className="w-full inline-block no-underline transition ease-in-out hover:text-indigo-900 transform  hover:scale-95 cursor-pointer font-semibold lg:-ml-2"
          >
            <LinkRoute to="/">Холбоо барих</LinkRoute>
          </Link>
        </li>
        <Divider />
        <li>
          <LinkRoute
            to="/careers"
            onClick={click}
            className="full inline-block no-underline transition ease-in-out hover:text-indigo-900 transform hover:scale-95 font-semibold cursor-pointer bg-yellow-400 p-2 lg:-ml-2"
          >
            Нээлттэй ажил
          </LinkRoute>
        </li>
        {/* <Divider />
        <li onClick={click}>
          <a
            className="inline-block no-underline transition ease-in-out hover:text-indigo-900 transform  hover:scale-95 cursor-pointer font-semibold lg:-ml-2"
            href="https://www.stora.mn/"
            target="_blank"
            rel="noreferrer"
          >
            Стора шоп
          </a>
        </li> */}
        <Divider />
        <li>
          {!localStorage.getItem("token") ? (
            <LinkRoute
              to="/users/signin"
              onClick={click}
              className="w-full inline-block no-underline transition ease-in-out text-white transform hover:scale-95 font-semibold cursor-pointer bg-indigo-900 p-2 lg:-ml-2"
            >
              Нэвтрэх
            </LinkRoute>
          ) : localStorage.getItem("role") === "user" ? (
            <LinkRoute
              to="/users"
              onClick={click}
              className="w-full inline-block no-underline transition ease-in-out text-white transform hover:scale-95 font-semibold cursor-pointer  bg-indigo-800 p-2 lg:-ml-2"
            >
              {localStorage.getItem("username")}
            </LinkRoute>
          ) : (
            <LinkRoute
              to="/admin"
              onClick={click}
              className="w-full inline-block no-underline transition ease-in-out  text-white transform hover:scale-95 font-semibold cursor-pointer bg-indigo-800 p-2 lg:-ml-2"
            >
              {localStorage.getItem("username")}
            </LinkRoute>
          )}
        </li>
      </ul>
    </div>
  );
};
export default Navbar;
