import React, { useState } from "react";
import img from "../../photos/logo.svg";
import axios from "axios";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import Alert from "@mui/material/Alert";
import Stack from "@mui/material/Stack";

const SignUp = ({ click }) => {
  const navigate = useNavigate();
  const [username, setUsername] = useState(null);
  const [password, setPassword] = useState(null);
  const [email, setEmail] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoad] = useState(false);

  const handleUsername = (e) => {
    setUsername(e.target.value);
  };
  const handlePassword = (e) => {
    setPassword(e.target.value);
  };
  const handleEmail = (e) => {
    setEmail(e.target.value);
  };
  const handleClick = (event) => {
    setLoad(true);
    axios
      .post("http://localhost:8000/api/users/signup", {
        name: username,
        email: email,
        password: password,
      })
      .then((result) => {
        setLoad(false);
        if (result.status === 200) {
          click(
            result.data.token,
            result.data.user.name,
            result.data.user.role,
            result.data.user._id
          );
        }
        navigate("/");
      })
      .catch((err) => {
        setError(err.response.data.error.message);
        console.log("errorrrrrrr: ", err.response.data.error.message);
      });
  };

  return (
    <div
      id="login"
      className="h-screen flex mx-auto justify-center items-center"
    >
      <div className="form">
        <div className="rounded-lg w-72    md:shadow-lg p-8 text-sm md:text-base bg-white md:bg-gray-200 md:bg-opacity-75">
          {loading && <div>loading...</div>}
          {error && (
            // <div className="bg-yellow-500 rounded mb-3 p-2">{error}</div>
            <Stack sx={{ width: "100%" }} spacing={2}>
              <Alert severity="warning">{error}</Alert>
            </Stack>
          )}
          <div className="space-y-4">
            <div className="flex justify-center">
              <img src={img} alt="logo" className="w-16 md:w-24" />
              {/* <div className=" text-3xl font-extrabold   ">
                <label className="text-yellow-500">HR</label>
                <label className="text-indigo-900">WEB</label>
              </div> */}
            </div>
            <div className="">
              <p>Нэвтрэх нэр</p>
              <input
                type="text"
                className="block w-full p-1 border rounded-md  shadow-lg  text-gray-700 focus:ring focus:outline-none text-sm"
                name="name"
                onChange={handleUsername}
                required
              />
            </div>
            <div className="">
              <p>И-мэйл</p>
              <input
                type="text"
                className="block w-full p-1 border rounded-md  shadow-lg  text-gray-700 focus:ring focus:outline-none text-sm"
                name="email"
                onChange={handleEmail}
                required
              />
            </div>
            <div>
              <p>Нууц үг</p>
              <input
                type="password"
                className="block w-full p-1 border rounded-md  shadow-lg  text-gray-700 focus:ring focus:outline-none text-sm"
                name="password"
                required
                onChange={handlePassword}
              />
            </div>
          </div>
          <div className=" mt-8">
            <button
              type="submit"
              className="submit-button  shadow-lg p-2 rounded-md bg-indigo-900 hover:bg-indigo-700 text-white focus:ring focus:outline-none w-full text-sm font-semibold transition-colors"
              onClick={handleClick}
            >
              Бүртгүүлэх
            </button>
          </div>
          <div className="flex justify-center pt-5">
            <Link to="/users/signin">
              <button className=" text-xs md:text-sm "> Нэвтрэх? </button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};
export default SignUp;
