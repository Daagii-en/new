import React from "react";
import img from "../../photos/logo.svg";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
import Spinner from "../career/index";
import { useState } from "react";
import Alert from "@mui/material/Alert";
import Stack from "@mui/material/Stack";

export default function Login({ onLogin }) {
  const navigate = useNavigate();
  const [email, setEmail] = useState(null);
  const [password, setPassword] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoad] = useState(null);
  const [forgotpass, setForgotPass] = useState(null);
  const handleForgotPass = () => {
    setForgotPass(!forgotpass);
    navigate("/users/signin");
  };
  const forgotPass = (e) => {
    axios
      .post("http://localhost:8000/api/users/forgot-password", {
        email: email,
      })
      .then((result) => {
        console.log(result.data);
        localStorage.setItem("resetToken", result.data.resetToken);
        alert("Нууц үг сэргээх хүсэлт хүлээн авлаа. Та имэйлээ шалгана уу.");
        // (<Stack sx={{ width: "100%" }} spacing={2}>
        //   <Alert severity="success">
        //     Нууц үг сэргээх хүсэлт хүлээн авлаа. Та имэйлээ шалгана уу!
        //   </Alert>
        // </Stack>)();
      })
      .catch((err) => {
        setError(err.response.data.error.message);
      });
  };
  const handleClick = (event) => {
    setLoad(true);
    axios
      .post("http://localhost:8000/api/users/signin", {
        email: email,
        password: password,
      })
      .then((result) => {
        setLoad(false);
        if (result.status === 200) {
          onLogin(
            result.data.token,
            result.data.user.name,
            result.data.user.role,
            result.data.user._id,
            result.data.user.email
          );
        }

        navigate("/");
      })
      .catch((err) => {
        setError(err.response.data.error.message);
        setLoad(false);
        console.log(err.response.data.error.message);
      });
  };
  return (
    <div
      id="login"
      className=" h-screen flex mx-auto justify-center items-center"
    >
      {!forgotpass ? (
        <div className="form">
          <div className="rounded-lg w-72  md:shadow-lg p-8  text-sm md:text-base bg-white md:bg-gray-200 md:bg-opacity-75">
            {error && (
              // <div className="bg-yellow-500 rounded mb-3 p-2">{error}</div>
              <Stack sx={{ width: "100%" }} spacing={2}>
                <Alert severity="warning">{error}</Alert>
              </Stack>
            )}
            <div className="space-y-5">
              <div className="flex justify-center">
                <img src={img} alt="logo" className="w-16 md:w-24" />
                {/* <div className=" text-3xl font-extrabold   ">
                  <label className="text-yellow-500">HR</label>
                  <label className="text-indigo-900">WEB</label>
                </div> */}
              </div>
              {loading && <Spinner />}
              <div className="">
                <p>И-мэйл</p>

                <input
                  type="text"
                  className="block w-full p-1 border rounded-md  shadow-lg  text-gray-700 focus:ring focus:outline-none text-sm"
                  name="email"
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setError(null);
                  }}
                  required
                />
              </div>
              <div>
                <p>Нууц үг</p>
                <input
                  type="password"
                  className="block w-full p-1 border rounded-md  shadow-lg  text-gray-700 focus:ring focus:outline-none text-sm"
                  name="password"
                  required
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setError(null);
                  }}
                />
              </div>
              <div className="flex justify-center">
                <button
                  onClick={handleForgotPass}
                  className=" text-xs md:text-sm "
                >
                  {" "}
                  Нууц үгээ мартсан?{" "}
                </button>
              </div>
            </div>

            <div className=" mt-6">
              <button
                type="submit"
                className="submit-button  shadow-lg p-2 rounded-md bg-indigo-900 hover:bg-indigo-700 text-white focus:ring focus:outline-none w-full text-sm font-semibold transition-colors"
                onClick={handleClick}
              >
                Нэвтрэх
              </button>
            </div>
            <div className="flex justify-center pt-4">
              <Link to="/users/signup">
                <button className=" text-xs md:text-sm "> Бүртгүүлэх? </button>
              </Link>
            </div>
          </div>
        </div>
      ) : (
        <div className="form">
          {/* <div className="text-xl font-extrabold">Нууц үг сэргээх</div> */}
          <div className="rounded-lg w-72  md:shadow-lg p-8  text-sm md:text-base bg-white md:bg-gray-200 md:bg-opacity-75">
            {error && <div className="warning">{error}</div>}
            <div className="space-y-5">
              <div className="flex justify-center">
                {/* <img src={img} alt="logo" className="w-16 md:w-24" /> */}
                <div className=" text-3xl font-extrabold   ">
                  <label className="text-yellow-500">HR</label>
                  <label className="text-indigo-900">WEB</label>
                </div>
              </div>
              <div className="">
                <p>И-мэйл</p>

                <input
                  type="text"
                  className="block w-full p-1 border rounded-md  shadow-lg  text-gray-700 focus:ring focus:outline-none text-sm"
                  name="email"
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
            </div>
            <div className=" mt-6">
              <button
                type="submit"
                className="submit-button  shadow-lg p-2 rounded-md bg-indigo-900 hover:bg-indigo-700 text-white focus:ring focus:outline-none w-full text-sm font-semibold transition-colors"
                onClick={forgotPass}
              >
                Нууц үг сэргээх
              </button>
            </div>
            <div className="flex justify-center">
              <button
                onClick={handleForgotPass}
                className=" text-xs md:text-sm "
              >
                {" "}
                Нэвтрэх{" "}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
