import React from "react";
import storabox from "../../photos/StoraBoxIcon.svg";
import "./footer.css";
import {
  FavoriteBorder,
  Copyright,
  Phone,
  MailOutline,
  CalendarMonth,
  Place,
  Facebook,
  Instagram,
  YouTube,
} from "@mui/icons-material";

const Footer = () => {
  return (
    <div
      id="contact"
      className="footer text-xs md:text-base text-white mt-5 pt-5 "
    >
      <p className="flex justify-center text-xl mb-5">Холбоо барих</p>
      <div className="md:flex space-x-8 mt-4 md:mt-0  mb-5 pt-5 pb-5 w-4/5 mx-auto">
        <div className="w-full md:w-4/12 px-3  items-center ">
          <div className="flex justify-center  ">
            <img src={storabox} alt="zurag" className="w-32 md:w-44"></img>
          </div>
          <div className="mt-5 mb-5 flex justify-around">
            <div>
              <a
                href="https://www.facebook.com/stora.mn"
                target="_blank"
                rel="noreferrer"
                className="cursor-pointer hover:text-blue-400 transition duration-500 ease-in-out transform hover:scale-110"
              >
                <Facebook sx={{ fontSize: 40 }} />
              </a>
            </div>
            <div>
              <a
                href="https://www.instagram.com/stora.mn/"
                target="_blank"
                rel="noreferrer"
                className="cursor-pointer hover:text-red-400 transition duration-500 ease-in-out transform   hover:scale-110"
              >
                <Instagram sx={{ fontSize: 40 }} />
              </a>
            </div>
            <div>
              <a
                href="https://www.facebook.com/stora.mn"
                target="_blank"
                rel="noreferrer"
                className="cursor-pointer hover:text-red-600 transition duration-500 ease-in-out transform   hover:scale-110"
              >
                <YouTube sx={{ fontSize: 40 }} />
              </a>
            </div>
          </div>
        </div>
        <div className="space-y-8  mt-5 md:mt-0">
          <p>
            <Phone /> Утас: <label>7507-7550</label>
          </p>
          <p>
            <a href="https://www.gmail.com" rel="noreferrer" target="_blank">
              <MailOutline /> Цахим шуудан: hrweb@hrweb.mn
              {/* support@stora.mn */}
            </a>
          </p>
          <p>
            <CalendarMonth /> Цагийн хуваарь: Даваа-Баасан 9:00-17:00
          </p>
          <p>
            <a
              href="https://www.google.com/maps/place/Dalai+Tower/@47.9125152,106.928672,18z/data=!3m1!4b1!4m5!3m4!1s0x5d96938fdbf60343:0x46342412fd152f3!8m2!3d47.9125144!4d106.9294149"
              target="_blank"
              rel="noreferrer"
            >
              <Place />
              Байршил: СБД, 1-р хороо, Юнескогийн гудамж, Далай Тауэр 701
            </a>
          </p>
        </div>
      </div>
      <div className="flex justify-center items-center pb-2">
        <Copyright sx={{ fontSize: 14 }}></Copyright>Stora 2023. Made with{" "}
        <FavoriteBorder sx={{ fontSize: 20 }}></FavoriteBorder> by Stora.
      </div>
    </div>
  );
};
export default Footer;
