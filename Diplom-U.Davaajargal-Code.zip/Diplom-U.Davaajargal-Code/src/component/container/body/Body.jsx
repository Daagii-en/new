import React, { useEffect } from "react";
import LineB from "../lineB/LineB";
import img from "./1067575c0e25ae9f34c20464de0bd630.jpg";
// import img2 from "./9a225b93b1ba1dcca2619bc67d125d59.jpg";
import AOS from "aos";
import "aos/dist/aos.css";
export default function Body() {
  return (
    <div
      id="body"
      // className="bg-gradient-to-t from-pink-500 via-red-500 to-indigo-500"
    >
      <div className="w-4/5 container mx-auto pt-10 pb-10 ">
        <LineB></LineB>
        <div className="text-xs md:text-base md:flex mt-5 space-y-3">
          <div className="md:mr-5 md:w-11/12">
            <h1
              data-aos="fade-up"
              className="text-xl md:text-2xl font-bold  mb-5"
            >
              Stora гэж юу вэ?
            </h1>
            <p data-aos="fade-up" className="mb-5">
              Стора нь онлайн худалдааны цогц платформ бөгөөд одоогоор дэлхийн
              худалдааны хамгийн том сайт Amazon.com-ийн бүтээгдэхүүнийг хамгийн
              хялбараар худалдан авах боломжийг хэрэглэгчддээ олгоод байна.
              Стора-гаас захиалсан бүтээгдэхүүнээ өөрт ойр СтораБоксоор
              дамжуулан авах боломжтой юм.
            </p>
            <div data-aos="fade-up" className="">
              Стора таны бараа бүтээгдэхүүний төлбөр тооцоо, тээвэрлэлт,
              хүргэлтийн аюулгүй байдлыг бүрэн хангаж, таны хүссэн бараа
              бүтээгдэхүүнийг танд найдвартай хүргэнэ.
            </div>
          </div>
          <div
            data-aos="fade-up"
            data-aos-anchor-placement="top-bottom"
            className="md:w-9/12 "
          >
            <img src={img} alt="zurag" className="" />
          </div>
        </div>
      </div>
      {/* <div className="w-full pt-10 pb-10">
        <div className=" md:flex w-4/5 mx-auto md:justify-between">
          <div
            data-aos="fade-up"
            data-aos-anchor-placement="top-bottom"
            className="md:w-9/12  md: mr-5"
          >
            <img src={img2} className="" alt="zurag" />
          </div>
          <div
            data-aos="fade-up"
            data-aos-anchor-placement="center-bottom"
            className="md:w-9/12 p-5 flex md:items-center text-white"
          >
            Стора таны бараа бүтээгдэхүүний төлбөр тооцоо, тээвэрлэлт,
            хүргэлтийн аюулгүй байдлыг бүрэн хангаж, таны хүссэн бараа
            бүтээгдэхүүнийг танд найдвартай хүргэнэ.
          </div>
        </div>
      </div> */}
    </div>
  );
}
