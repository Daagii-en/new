import React, { useEffect } from "react";

import image from "./627d26cb0a6ef4e98a0dcfdee74e0e6a.jpg";
import ArrowDownwardRoundedIcon from "@mui/icons-material/ArrowDownwardRounded";
import LineB from "../lineB/LineB";
import AOS from "aos";
import "aos/dist/aos.css";

export default function About() {
  useEffect(() => {
    AOS.init({
      offset: 50,
      duration: 500,
      easing: "ease",
      once: true,
      mirror: false,
      anchorPlacement: "top-bottom",
    });
  }, []);
  return (
    <>
      <div
        id="about"

        // bg-gradient-to-b from-indigo-500 via-pink-500 to-indigo-500"
      >
        <div className="w-full  container items-center text-center">
          <div className="pt-3 flex justify-center">
            <ArrowDownwardRoundedIcon
              className="animate-bounce"
              style={{ color: "#201B43" }}
              sx={{ fontSize: 30 }}
            />
          </div>

          <h1
            data-aos="fade-up"
            data-aos-anchor-placement="top-bottom"
            className="text-2xl  font-extrabold pt-5 p-3  "
            style={{ color: "#201B43" }}
          >
            {/* It’s a<label className="text-yellow-400">ll</label> inside */}
            It’s HR<label className="text-yellow-400">WEB</label>
          </h1>
        </div>
        <div className="w-4/5  text-xs md:text-base container mx-auto pb-10">
          <LineB></LineB>
          <h1
            data-aos="fade-up"
            data-aos-anchor-placement="top-bottom"
            className="text-xl md:text-2xl font-bold mt-5 mb-5"
          >
            Бидний тухай
          </h1>
          <p
            data-aos="fade-up"
            data-aos-anchor-placement="top-bottom"
            className="pb-4"
          >
            Бид танд Amazon.com болон бусад худалдааны сайтуудын өргөн сонголт
            бүхий бараа бүтээгдэхүүнийг өөрсдийн үйлчилгээгээр дамжуулан илүү
            хялбараар худалдан авах боломжийг олгож байна.
          </p>
          <p
            data-aos="fade-up"
            data-aos-anchor-placement="top-bottom"
            className="pb-8"
          >
            Хамгийн өргөн сонголтыг хялбар, найдвартай ая тухтайгаар
            хэрэглэгчдэдээ хүргэн, үйлчилгээгээ тасралтгүй сайжруулан хил
            дамнасан онлайн худалдааг хүн бүрийн хэрэглээ болгох зорилготой.
            Ойрын ирээдүйд АНУ, Япон, Солонгос, Хятад зэрэг зах зээлээс худалдан
            авах боломжийг нэгтгэсэн цогт платформыг бий болгох төлөвлөгөөтэй
            ажиллаж байна.
          </p>
          <div className="md:flex  justify-between ">
            <div
              data-aos="zoom-in"
              className=" md:w-10/12 flex justify-center items-center"
            >
              <img
                className="w-full md:h-5/6 shadow-lg"
                src={image}
                alt="zurag"
              />
            </div>
            <div
              data-aos="fade-up"
              data-aos-anchor-placement="center-bottom"
              // className="bg-gray-100 overflow-y-scroll md:overflow-hidden shadow h-60  p-9 rounded-3xl text-justify italic bg-opacity-50 "
              className="md:w-full p-10  justify-center items-center bg-amber-400"
            >
              <div className="w-full h-full flex justify-center items-center">
                <div>
                  “Би 2018 оноос хойш худалдааны жижиг, том олон төсөл дээр
                  ажиллаж байхдаа манай улсад онлайн худалдааны хэрэглэгчийн
                  туршлага бага, салбарын хувьд шийдэх асуудлууд их байгааг олж
                  харсан. Онлайн худалдааг илүү энгийн болгож, хэрэглэгч хялбар
                  аргаар захиалах, захиалсан бараа бүтээгдэхүүнээ хаана явааг
                  хянах, хүргэлтийн ухаалаг үйлчилгээг нэвтрүүлэх зорилгоор
                  Стораг үүсгэн байгуулсан.”
                  <p className="text-right">Гүйцэтгэх захирал Т.Билгүүн</p>
                </div>
              </div>
              <div className="text-right"></div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
