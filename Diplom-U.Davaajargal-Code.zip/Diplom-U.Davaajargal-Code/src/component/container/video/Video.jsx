import React from "react";
import video2 from "./storaVideo3.mp4";
const Video = () => {
  return (
    <div className="w-full ">
      <video autoPlay loop muted>
        <source src={video2} />
      </video>
    </div>
  );
};
export default Video;
