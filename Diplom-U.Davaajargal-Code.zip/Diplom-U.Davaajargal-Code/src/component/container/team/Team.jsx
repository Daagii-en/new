import React from "react";
import teamOfImage from "./8c4adc391bd23ad0fe8509a0f859e20e.jpg";
// import teamOfImage from "./team.jpg";
import LineB from "../lineB/LineB";
const Team = () => {
  return (
    <div
      id="team"
      className="mt-5"

      // className="bg-gradient-to-b from-blue-400 via-indigo-500 to-pink-500 "
    >
      <div className="w-4/5 text-xs md:text-base   mx-auto pt-10 pb-10">
        <LineB></LineB>
        <h1
          data-aos="fade-up"
          className=" text-xl md:text-2xl font-bold  mb-5 mt-5"
        >
          Манай баг
        </h1>
        <p data-aos="fade-up" data-aos-anchor-placement="top-bottom">
          Манай баг 14 хүний бүрэлдэхүүнтэй. Технологи, логистик, хэрэглэгчийн
          үйлчилгээ, маркетинг гэсэн бүтцээр ажилладаг. Багийнхан маань өөрсдөө
          “Stora”-гийнхаа байнгын хэрэглэгчид. “Stora”-д донтчихлоо гэдэг
          хөгжилтэй яриа ч оффист гардаг.
        </p>
        <div data-aos="fade-up" className="flex justify-center">
          <img
            src={teamOfImage}
            alt="zugar"
            className="md:w-3/4 mt-10 transition duration-500 ease-in-out transform  hover:scale-105"
          ></img>
        </div>
      </div>
    </div>
  );
};
export default Team;
