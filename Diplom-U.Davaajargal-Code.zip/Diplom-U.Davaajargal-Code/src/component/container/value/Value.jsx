import React from "react";
import LineB from "../lineB/LineB";

const Value = () => {
  return (
    // bg-gradient-to-t from-green-500  via-blue-500 to-pink-500
    <div
      id="value"
      // style={{
      //   backgroundImage: `url(${image})`,
      //   backgroundRepeat: "no-repeat",
      //   backgroundSize: "contain",
      // }}
      className="w-full mt-10  container  "
    >
      <div className="w-4/5 text-xs md:text-base  mx-auto ">
        <LineB></LineB>
        <h1 data-aos="fade-up" className="text-xl md:text-2xl font-bold  mt-5">
          Бидний үнэт зүйл
        </h1>
        <div className="overflow-y-scroll h-80 lg:h-auto lg:overflow-hidden ">
          <div className="block lg:flex justify-between mb-2 md:mb-0 p-5 md:pt-10 md:pb-5 ">
            <div className="bg-gray-200 bg-opacity-50  mb-2 p-5 w-auto h-auto lg:w-72 lg:h-72 rounded-2xl transition duration-500 ease-in-out hover:text-black hover:font-semibold hover:bg-opacity-75 transform  hover:scale-110">
              Бид хэрэглэгчдэдээ ая тухтай үйлчилгээг санал болгодог. Онлайн
              худалдааны үйлчилгээг яагаад ая тухтай буюу конвинент гэж байгаа
              вэ гэвэл хэрэглэгч тухайн барааны захиалгыг хийхээс эхлээд төлбөр
              төлөх, ачаа хүлээн авах бүх процесст хэн нэгэн хүнтэй харилцах
              шаардлагагүй.
            </div>
            <div className="bg-gray-200 bg-opacity-50 mb-2 md:mb-0  p-5 w-auto h-auto lg:w-72 lg:h-72  rounded-2xl transition duration-500 ease-in-out hover:text-black hover:font-semibold hover:bg-opacity-75 transform  hover:scale-110">
              Захиалгын явцыг бүх шатанд хянаж, бараа ирсэн дариуд Монголд
              хамгийн олон салбартай 24 цагаар үйлчилдэг CU сүлжээ дэлгүүрүүд
              дэх СтораБоксоос өдрийн аль ч цагт хүлээн авах боломжийг бид санал
              болгодог.
            </div>
            <div className=" bg-gray-200 bg-opacity-50 p-5 w-auto h-auto lg:w-72 lg:h-72  rounded-2xl transition duration-500 ease-in-out hover:text-black hover:font-semibold hover:bg-opacity-75 transform  hover:scale-110">
              Бид дотоодын төлбөрийн хэрэгслүүдээр төлбөр төлөх бүх боломжийг
              нэвтрүүлсэн. Мөн бид хэрэглэгчийн захиалсан бараа бүтээгдэхүүн
              асуудалтай ирсэн тохиолдолд буцаалт хийх үйлчилгээг санал болгодог
              нь бидний бас нэгэн давуу тал юм
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Value;
