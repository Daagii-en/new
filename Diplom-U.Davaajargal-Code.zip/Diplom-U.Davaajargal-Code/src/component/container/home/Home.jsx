import React from "react";
import bg from "./temp2.jpg";
const Home = () => {
  return (
    <div id="home" className="pt-12 md:pt-16">
      <div className="  w-full flex justify-center items-center ">
        <img src={bg} alt="background" className=" opacity-100 w-full " />
        <label
          className="z-0 absolute text-2xl md:text-5xl lg:text-7xl label text-indigo-900  font-extrabold animate-pulse "
          // style={{ color: "#201B43" }}
        >
          WELCOME TO HRWEB
        </label>
      </div>
    </div>
  );
};
export default Home;
