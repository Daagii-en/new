import React, { useEffect } from "react";
import LineB from "../lineB/LineB";
import AOS from "aos";
import "aos/dist/aos.css";
const Timeline = () => {
  useEffect(() => {
    AOS.init();
  }, []);
  return (
    // bg-gradient-to-t from-blue-400 to-green-500
    <div className="">
      <div className="w-4/5 container mx-auto pt-10 pb-10  ">
        <LineB></LineB>
        <h1
          data-aos="fade-up"
          data-aos-anchor-placement="top-bottom"
          className="text-xl md:text-2xl  font-bold  mb-5 mt-5"
        >
          Он цаг
        </h1>
        <div className="w-10/12 md:w-7/12 lg:6/12 mx-auto relative ">
          <div className="border-l-2 mt-10">
            {/* <!-- Card 1 --> */}
            <div className="transform transition cursor-pointer hover:-translate-y-2 ml-10 relative flex items-center px-6 py-4 bg-blue-600 text-white rounded mb-10 flex-col md:flex-row space-y-4 md:space-y-0">
              {/* <!-- Dot Follwing the Left Vertical Line --> */}
              <div className="w-5 h-5 bg-blue-600 absolute -left-10 transform -translate-x-2/4 rounded-full z-10 mt-2 md:mt-0"></div>

              {/* <!-- Line that connecting the box with the vertical line --> */}
              <div className="w-10 h-1 bg-blue-300 absolute -left-10 z-0"></div>

              {/* <!-- Content that showing in the box --> */}
              <div className="flex-auto">
                <h1 className="text-lg">2020</h1>
                <h1 className="md:text-xl font-bold">
                  Stora.mn үүсгэн байгуулагдсан
                </h1>
              </div>
            </div>

            {/* <!-- Card 2 --> */}
            <div className="transform transition cursor-pointer hover:-translate-y-2 ml-10 relative flex items-center px-6 py-4 bg-pink-600 text-white rounded mb-10 flex-col md:flex-row space-y-4 md:space-y-0">
              {/* <!-- Dot Follwing the Left Vertical Line --> */}
              <div className="w-5 h-5 bg-pink-600 absolute -left-10 transform -translate-x-2/4 rounded-full z-10 mt-2 md:mt-0"></div>

              {/* <!-- Line that connecting the box with the vertical line --> */}
              <div className="w-10 h-1 bg-pink-300 absolute -left-10 z-0"></div>

              {/* <!-- Content that showing in the box --> */}
              <div className="flex-auto">
                <h1 className="text-lg">2021</h1>
                <h1 className="md:text-xl font-bold">
                  Үйл ажиллагааны сайжруулалт
                </h1>
              </div>
            </div>

            {/*  Card 3  */}
            <div className="transform transition cursor-pointer hover:-translate-y-2 ml-10 relative flex items-center px-6 py-4 bg-green-600 text-white rounded mb-10 flex-col md:flex-row space-y-4 md:space-y-0">
              {/* <!-- Dot Follwing the Left Vertical Line --> */}
              <div className="w-5 h-5 bg-green-600 absolute -left-10 transform -translate-x-2/4 rounded-full z-10 mt-2 md:mt-0"></div>

              {/* <!-- Line that connecting the box with the vertical line --> */}
              <div className="w-10 h-1 bg-green-300 absolute -left-10 z-0"></div>

              {/* <!-- Content that showing in the box --> */}
              <div className="flex-auto">
                <h1 className="text-lg">2022</h1>
                <h1 className="md:text-xl font-bold">StoraBox</h1>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Timeline;
