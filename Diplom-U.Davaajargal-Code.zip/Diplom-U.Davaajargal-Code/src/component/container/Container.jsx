import React from "react";
import { useEffect } from "react";
import Body from "./body/Body";
import Video from "./video/Video";
import Timeline from "./timeline/Timeline";
import Value from "./value/Value";
import Team from "./team/Team";
import About from "./about/AboutUs";
import Partners from "./partners/Partners";
import Home from "./home/Home";
import Footer from "../footer/Footer";
import AOS from "aos";
import "aos/dist/aos.css";
const Container = () => {
  useEffect(() => {
    AOS.init({
      offset: 50,
      duration: 500,
      easing: "ease",
      once: false,
      mirror: false,
      anchorPlacement: "top-bottom",
    });
  }, []);
  return (
    <div id="/">
      <Home />
      <About />
      <Video />
      <Body />
      <Value />
      <Timeline />
      <Team />
      <Partners />
      <Footer />
    </div>
  );
};
export default Container;
