import "./lineB.css";
import React, { useEffect } from "react";
import AOS from "aos";
import "aos/dist/aos.css";
function LineB() {
  useEffect(() => {
    AOS.init();
  }, []);
  return (
    <div
      data-aos="fade-up"
      data-aos-anchor-placement="top-bottom"
      className="line w-24 h-1.5 md:w-36 md:h-2.5"
    ></div>
  );
}
export default LineB;
