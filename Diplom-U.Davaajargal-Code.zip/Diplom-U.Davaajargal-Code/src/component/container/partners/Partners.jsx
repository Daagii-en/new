import React from "react";
import LineB from "../lineB/LineB";
import Cu from "./1200px-CU_BI_2017.svg.png";
import amazon from "./amazon-png-logo-vector-1.png";
import golomt from "./Golomt-bank-logo-mn-1.png";
import monpay from "./monpay-brand-logo.png";
const Partners = () => {
  return (
    // className="bg-gradient-to-t from-blue-400 via-indigo-500 to-pink-500"
    <div id="partner">
      <div className="w-4/5   mx-auto pt-10 pb-5">
        <LineB></LineB>
        <h1 data-aos="fade-up" className="text-2xl  font-bold  mb-5 mt-5">
          Хамтрагч байгууллагууд
        </h1>
        <div className="overflow-x-auto md:overflow-hidden">
          <div className="flex justify-around  min-w-min h-28 mt-10 mb-10">
            <div
              data-aos="fade-up"
              data-aos-duration="200"
              className="w-40 flex items-center justify-center"
            >
              <img
                src={Cu}
                alt="zurag"
                className="w-32 transition duration-500  ease-in-out transform  hover:scale-110"
              ></img>
            </div>
            <div
              data-aos="fade-up"
              data-aos-duration="250"
              className="w-40 flex items-center justify-center "
            >
              <img
                src={amazon}
                alt="zurag"
                className="w-40 transition duration-500  ease-in-out transform  hover:scale-110"
              ></img>
            </div>
            <div
              data-aos="fade-up"
              data-aos-duration="300"
              className="w-40 flex items-center justify-center "
            >
              <img
                src={golomt}
                alt="zurag"
                className="w-32 transition duration-500  ease-in-out transform  hover:scale-110"
              ></img>
            </div>
            <div
              data-aos="fade-up"
              data-aos-duration="350"
              className="w-40 flex  items-center justify-center "
            >
              <img
                src={monpay}
                alt="zurag"
                className="w-28 transition duration-500  ease-in-out transform  hover:scale-110"
              ></img>
            </div>
            <div
              data-aos="fade-up"
              data-aos-duration="400"
              className="w-40 flex items-center justify-center "
            >
              <svg
                className="bi me-2 transition duration-500 ease-in-out transform  hover:scale-110"
                width="100"
                fill="currentColor"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 186.7 73.6"
              >
                <path d="M111.4 13.5c3.1 2.8 4.7 7 4.7 12.4s-1.6 9.5-4.7 12.4-7.3 4.3-12.4 4.3h-5.9V58c-1.8.3-3.6.5-5.5.4-1.8 0-3.6-.1-5.4-.4V10l.5-.5c7.9-.2 13.3-.3 16.2-.3 5.2.1 9.4 1.5 12.5 4.3zm-18.3 4v17c1.4 0 3-.1 4.9-.1 1.6.1 3.2-.4 4.5-1.5 1-.8 1.7-1.9 2.1-3.1.3-1.5.5-2.9.5-4.4 0-1.9-.5-3.7-1.5-5.2-1.1-1.7-3-2.7-5-2.5-2.4-.1-4.2-.1-5.5-.2zM150.9 53.2c-.3 1.1-.7 2.1-1.3 3-.5.9-1.2 1.7-2 2.4-2.9 0-5.7-1.4-7.4-3.8-2.6 2.7-6.2 4.2-10 4.2-3.7 0-6.4-1.1-8.3-3.3-1.8-2-2.8-4.7-2.8-7.4 0-4 1.3-7 4-9.1 2.9-2.2 6.4-3.3 10-3.1 1.6 0 3.3.1 5.3.2v-1.5c0-3.1-1.6-4.7-4.8-4.7-2 0-5.5.8-10.6 2.3-1.4-1.6-2.3-4.1-2.6-7.4 2.5-1 5.2-1.8 7.9-2.3 2.6-.5 5.3-.8 8-.8 3.2-.1 6.4.9 8.9 2.9 2.4 2 3.6 5 3.6 9.1v14.4c.1 2.4.7 3.9 2.1 4.9zm-18.1-1.9c2.1-.1 4-.9 5.5-2.3v-5.9c-1 0-2.4-.1-4.2-.1-3.2 0-4.7 1.6-4.7 4.7 0 .9.4 1.8 1 2.5s1.5 1.1 2.4 1.1zM186.7 23.9l-8.9 33.2c-1.5 5.5-3.4 9.7-5.9 12.4-2.5 2.7-6.2 4.1-11.2 4.1-2.8 0-5.7-.5-8.4-1.4v-1.3c.1-1 .2-2 .5-3 .3-1.2.8-2.3 1.6-3.2 2 .6 4.1 1 6.2 1.1 3.5 0 5.9-2.1 7.1-6.2l.3-1c-4-.1-6.3-1.6-7.1-4.4l-8.4-30.6c1.8-.9 3.8-1.4 5.8-1.4 1.4-.1 2.8.2 3.9 1 1 1 1.6 2.2 1.8 3.5l3.5 14c.4 1.4.9 4.5 1.7 9.4 0 .3.3.5.6.5l6.4-27.8c1.5-.3 3.1-.5 4.6-.4 1.8 0 3.5.2 5.2.8l.7.7zM52.6 52.2l3.8 3.8c1.5-1.5 2.8-3.1 3.9-4.8l-4.4-2.9c-1 1.4-2.1 2.7-3.3 3.9z"></path>
                <path d="M65.8 32.9v-.2c0-2.1-.2-4.1-.7-6.2V26C61.9 11 48.7.2 33.3 0h-.4C14.7 0 0 14.7 0 32.9s14.7 32.9 32.9 32.9c3.3 0 6.5-.5 9.6-1.4l1.1-.3 2.1-.8 2.6 1 8.5 3.3c1.4.6 1.8 0 .9-1.2L44.1 48c-1-1.3-2.7-1.7-4.1-1-2.2 1.1-4.6 1.7-7 1.8-8.8 0-16-7.1-16.1-15.9s7.1-16 15.9-16.1c7.6 0 14.2 5.3 15.7 12.7v.5c.2.9.2 1.8.3 2.7v.3c0 1-.1 1.9-.3 2.9l5.4 1c.2-1.3.4-2.6.4-3.9v-.2h6.2v.2c0 1.7-.1 3.4-.4 5.1v.2h-.2l-5.6-1.1c-.3 1.3-.7 2.6-1.2 3.9l-.1.2-.2-.1-5-2.1c-.4.9-.8 1.7-1.4 2.5l-.1.2c-.5.8-1.2 1.5-1.8 2.2l3.9 3.8c.9-.9 1.8-2 2.5-3.1l.1-.2.2.1 4.8 3.2c.9-1.4 1.7-2.9 2.4-4.5l.1-.2.2.1 4.9 2c.8-1.9 1.4-3.9 1.8-5.9v-.2c.2-2.1.4-4.1.4-6.2z"></path>
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Partners;
