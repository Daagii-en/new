import { List } from "@mui/material";
import React, { useEffect, useState } from "react";
import LineB from "../container/lineB/LineB";
import axios from "axios";
import { Delete } from "@mui/icons-material";
const Button = (career) => {
  // console.log("uurchlult", career);
  return (
    <button className="border border-lime-400  rounded-md w-52 py-2 px-3 hover:bg-lime-400">
      Өөрчлөх
    </button>
  );
};
const AllCareer = () => {
  const [careers, setCareers] = useState([]);
  const [career, setChangeCareer] = useState({
    name: null,
    skill: [null],
    worktime: null,
  });
  const [error, setError] = useState(null);

  useEffect(() => {
    axios
      .get("http://localhost:8000/api/careers")
      .then((result) => setCareers(result.data.data))
      .catch((err) => setError(err.response));
  });

  const deleteButton = (id) => {
    axios
      .delete(`http://localhost:8000/api/careers/${id}`, {
        headers: {
          authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      })
      .then((result) => {
        // console.log(result.data);
        alert("Амжилттай ажлын зар устгалаа...");
      })
      .catch((err) => {
        setError(err.response.data.error.message);
        alert("Алдаа гарлаа та дахин оролдоно уу...");
      });
  };
  const handleDataChange = (id) => {
    console.log(id);
  };
  return (
    <div className=" h-full  md:w-3/4 space-y-4 p-3 md:p-10 text-sx text-xs">
      <div className="text-xl font-bold ">Ажлын зарын мэдээлэл өөрчлөх</div>
      <LineB></LineB>
      <div className="space-y-3  rounded-md border p-6 ">
        <div className="space-y-3">
          <List>Ажлын зарууд</List>
        </div>
        <div className="flex pt-3">
          <div className="space-y-3  w-full ">
            <ul className="space-y-3">
              {careers.map((e, i) => {
                return (
                  <li
                    key={e.id}
                    className=" space-y-3 p-4 rounded-md box-border bg-slate-100 opacity-75"
                  >
                    <div className="">
                      <div className="pb-2 text-bold">
                        Ажлын байр:{" " + e.name}
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <div>Чадвар:</div>
                      <div>
                        <ul>
                          {e.skill.map((el, i) => {
                            return <li key={i}> - {el}</li>;
                          })}
                        </ul>
                      </div>
                    </div>
                    <div className="md:flex justify-between space-y-3">
                      <div className="">
                        Огноо: {" " + e.createdAt.split("T")[0]}
                      </div>
                    </div>
                    <div className="">
                      Сүүлийн хугацаа: {" " + e.endDate.split("T")[0]}
                    </div>
                    <div className="flex space-x-5 pt-3">
                      {/* <button
                        onClick={handleDataChange}
                        className="border border-lime-400  rounded-md w-52 py-2 px-3 hover:bg-lime-400"
                      >
                        Өөрчлөх
                      </button> */}
                      {/* <Button
                        career={{
                          id: e.id,
                          name: career.name,
                          skill: career.skill,
                          worktime: career.worktime,
                        }}
                      ></Button> */}
                      <button
                        onClick={() => deleteButton(e.id)}
                        className="border border-red-500 rounded-md w-52 py-2 px-3 hover:bg-red-500"
                      >
                        Устгах <Delete fontSize="small" />
                      </button>
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AllCareer;
