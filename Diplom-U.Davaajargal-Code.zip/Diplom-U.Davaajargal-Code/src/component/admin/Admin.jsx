import React, { useState } from "react";
import { Avatar, Badge, IconButton } from "@mui/material";
import LogoutIcon from "@mui/icons-material/Logout";
import EditIcon from "@mui/icons-material/Edit";
import PasswordIcon from "@mui/icons-material/Password";
import FolderSharedIcon from "@mui/icons-material/FolderShared";
import NoteAddOutlinedIcon from "@mui/icons-material/NoteAddOutlined";
import NoteAltOutlinedIcon from "@mui/icons-material/NoteAltOutlined";
import CreateCareer from "./CreateJob";
import Resumes from "./Resumes";
import { Link } from "react-router-dom";
import AllCareer from "./AllCareer";
import ChangePassword from "../user/ChangePassword";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
const Admin = ({ onLogout }) => {
  //const [...register, setRegister] = useState(["myCv",])
  let [click, setClick] = useState(false);
  const [checkResume, setCheckResume] = useState(false);
  const [addCareer, setAddCareer] = useState(true);
  const [allCareer, setAllCareer] = useState(false);
  const [changepass, setChangepass] = useState(false);
  const checkResumes = () => {
    setAddCareer(false);
    setCheckResume(true);
    setAllCareer(false);
    setChangepass(false);
    setClick(!click);
  };
  const addJobButton = () => {
    setAddCareer(true);
    setCheckResume(false);
    setAllCareer(false);
    setChangepass(false);
    setClick(!click);
  };

  const allJobButton = () => {
    setAddCareer(false);
    setCheckResume(false);
    setAllCareer(true);
    setChangepass(false);
    setClick(!click);
  };
  const changePassButton = () => {
    setAddCareer(false);
    setCheckResume(false);
    setAllCareer(false);
    setChangepass(true);
    setClick(!click);
  };
  const handleClick = () => {
    setClick(!click);
    // setAddCareer(false);
    // setCheckResume(false);
    // setAllCareer(false);
    // setChangepass(false);
  };
  const switchFunc = () => {
    if (addCareer === true) return <CreateCareer />;
    else if (checkResume === true) return <Resumes />;
    else if (allCareer === true) return <AllCareer />;
    else if (changepass === true) return <ChangePassword />;
  };
  return (
    <div className="flex justify-center w-full h-full">
      <div className="w-full md:px-6  h-full sm:flex mt-16 md:mt-18">
        {!click ? (
          <div className="p-2">
            <button onClick={handleClick} className=" sm:hidden">
              {" "}
              <ArrowForwardIosIcon />{" "}
            </button>
          </div>
        ) : (
          <div className="p-2">
            <button onClick={handleClick} className=" sm:hidden">
              {" "}
              <ArrowBackIosIcon />{" "}
            </button>
          </div>
        )}
        {click ? (
          <div className="h-full sm:hidden border-r border-amber-400 p-3 space-y-4">
            {/* <div className="w-full m-auto">
              <div className="flex justify-center">
                <Badge
                  overlap="circular"
                  anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
                  badgeContent={
                    <IconButton
                      color="secondary"
                      aria-label="upload picture"
                      component="label"
                    >
                      <input hidden accept="image/*" type="file" />
                      <EditIcon />
                    </IconButton>
                  }
                >
                  <Avatar
                    alt="Travis Howard"
                    sx={{ width: 80, height: 80 }}
                    src="/static/images/avatar/2.jpg"
                  />
                </Badge>
              </div>
            </div> */}
            <div className="flex justify-center ">
              {localStorage.getItem("username")}
            </div>
            <div className="md:px-8 space-y-6">
              <div className=" rounded-md w-52 py-2 px-3 hover:bg-amber-200 ">
                <button
                  onClick={addJobButton}
                  className="w-full flex items-center space-x-2 "
                >
                  <NoteAddOutlinedIcon /> <p>Ажлын зар нэмэх</p>
                </button>
              </div>
              <div className=" rounded-md w-60 py-2 px-3 hover:bg-amber-200 ">
                <button
                  onClick={allJobButton}
                  className="w-full flex items-center space-x-2 "
                >
                  <NoteAltOutlinedIcon /> <p>Ажлын зар өөрчлөх</p>
                </button>
              </div>
              <div className=" rounded-md w-52 py-2 px-3 hover:bg-amber-200 ">
                <button
                  onClick={checkResumes}
                  className="w-full flex items-center space-x-2 "
                >
                  <FolderSharedIcon /> <p>Анкет шалгах</p>
                </button>
              </div>
              <div className=" rounded-md w-52 py-2 px-3 hover:bg-amber-200 ">
                <button
                  onClick={changePassButton}
                  className="w-full flex items-center space-x-2 "
                >
                  <PasswordIcon /> <p>Нууц үг солих</p>
                </button>
              </div>
              <div className=" rounded-md w-52 py-2 px-3 hover:bg-amber-200 ">
                <Link to="/">
                  <button
                    onClick={onLogout}
                    className="w-full w-full flex items-center space-x-2 "
                  >
                    <LogoutIcon /> <p>Гарах</p>
                  </button>
                </Link>
              </div>
            </div>
          </div>
        ) : null}
        <div className="w-1/4 h-full hidden sm:inline border-r border-amber-400     md:pt-10 space-y-4">
          {/* <div className="flex justify-center">
            <Badge
              overlap="circular"
              anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
              badgeContent={
                <IconButton
                  color="secondary"
                  aria-label="upload picture"
                  component="label"
                >
                  <input hidden accept="image/*" type="file" />
                  <EditIcon />
                </IconButton>
              }
            >
              <Avatar
                alt="Travis Howard"
                sx={{ width: 80, height: 80 }}
                src="/static/images/avatar/2.jpg"
              />
            </Badge>
          </div> */}
          <div className="flex justify-center ">
            {localStorage.getItem("username")}
          </div>
          {/* <div className="flex justify-center text-xs">Админ</div> */}

          <div className="md:px-8 space-y-6">
            <div className=" rounded-md w-52 py-2 px-3 hover:bg-amber-200 ">
              <button
                onClick={addJobButton}
                className="w-full flex items-center space-x-2 "
              >
                <NoteAddOutlinedIcon /> <p>Ажлын зар нэмэх</p>
              </button>
            </div>
            <div className=" rounded-md w-60 py-2 px-3 hover:bg-amber-200 ">
              <button
                onClick={allJobButton}
                className="w-full flex items-center space-x-2 "
              >
                <NoteAltOutlinedIcon /> <p>Ажлын зар өөрчлөх</p>
              </button>
            </div>
            <div className=" rounded-md w-52 py-2 px-3 hover:bg-amber-200 ">
              <button
                onClick={checkResumes}
                className="w-full flex items-center space-x-2 "
              >
                <FolderSharedIcon /> <p>Анкет шалгах</p>
              </button>
            </div>
            <div className=" rounded-md w-52 py-2 px-3 hover:bg-amber-200 ">
              <button
                onClick={changePassButton}
                className="w-full flex items-center space-x-2 "
              >
                <PasswordIcon /> <p>Нууц үг солих</p>
              </button>
            </div>
            <div className=" rounded-md w-52 py-2 px-3 hover:bg-amber-200 ">
              <Link to="/">
                <button
                  onClick={onLogout}
                  className="w-full w-full flex items-center space-x-2 "
                >
                  <LogoutIcon /> <p>Гарах</p>
                </button>
              </Link>
            </div>
          </div>
        </div>
        <div className="sm:hidden">{!click && switchFunc()}</div>
        <div className="hidden sm:inline w-full">{switchFunc()}</div>
      </div>
    </div>
  );
};
export default Admin;
