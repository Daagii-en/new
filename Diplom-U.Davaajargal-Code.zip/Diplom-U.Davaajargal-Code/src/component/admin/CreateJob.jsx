import { TextField } from "@mui/material";
import React, { useState } from "react";
import LineB from "../container/lineB/LineB";
import AddCircleOutlineRoundedIcon from "@mui/icons-material/AddCircleOutlineRounded";
import axios from "axios";
import { Delete } from "@mui/icons-material";
const CreateJob = () => {
  const [name, setJobname] = useState(null);
  const [skill, setSkill] = useState([String]);
  const [worktime, setJobStatus] = useState(null);
  const [endDate, setEndDate] = useState(null);
  let [error, setError] = useState(null);
  const addSkill = (e) => {
    setSkill([...skill, ""]);
  };
  const handleDelete = (i) => {
    const deleteVal = [...skill];
    deleteVal.splice(i, 1);
    setSkill(deleteVal);
  };
  const handleChange = (e, i) => {
    const changeSkill = [...skill];
    changeSkill[i] = e.target.value;
    setSkill(changeSkill);
  };
  const addData = () => {
    if (name !== null && worktime !== null) {
      axios
        .post(
          "http://localhost:8000/api/careers",
          {
            name: name,
            skill: skill,
            worktime: worktime,
            endDate: endDate,
          },
          {
            headers: {
              authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          }
        )
        .then((result) => {
          // console.log(result.data);
          alert("Амжилттай ажлын зар орууллаа...");
        })
        .catch((err) => {
          setError(err.response.data.error.message);
          alert("Алдаа гарлаа та дахин оролдоно уу...");
        });
    }
  };
  return (
    <div className=" h-full   md:w-3/4 space-y-4 md:p-10 p-3 text-sx text-xs">
      <div className="text-xl font-bold ">Шинэ ажлын зар нэмэх</div>
      <LineB></LineB>
      <div className="space-y-3 rounded-md border p-6 bg-slate-100">
        {error && <div className="warning">{error}</div>}
        <div className="space-y-3">
          <div>
            <p>Ажлын байрыг тодорхойлох нэр: </p>
            <TextField
              id="outlined-basic"
              size="small"
              className="w-full"
              variant="outlined"
              required
              onChange={(e) => setJobname(e.target.value)}
            />
          </div>
          <div>
            <p>Шаардлагатай ур чадвар:</p>
            <div className="items-center">
              {skill.map((e, i) => {
                return (
                  <div className="flex space-x-1 items-center">
                    <TextField
                      size="small"
                      className="w-full"
                      variant="outlined"
                      key={i}
                      onChange={(e) => handleChange(e, i)}
                    ></TextField>
                    <button
                      className="bg-inherit rounded p-2 hover:bg-red-500"
                      onClick={() => handleDelete(i)}
                    >
                      <Delete />
                    </button>
                  </div>
                );
              })}
              <button
                className="bg-inherit rounded mt-2 p-2 hover:bg-lime-500"
                onClick={addSkill}
              >
                Шаардлага нэмэх <AddCircleOutlineRoundedIcon />
              </button>
            </div>
          </div>
          <div>
            <p>Ажлын байрны ажиллах төлөв:</p>
            <TextField
              id="outlined-basic"
              size="small"
              className="w-full"
              variant="outlined"
              required
              onChange={(e) => setJobStatus(e.target.value)}
            />
          </div>
          <div>
            <p>Анкет хүлээн авах сүүлийн хугацаа:</p>
            <TextField
              id="outlined-basic"
              size="small"
              className="w-full"
              variant="outlined"
              required
              onChange={(e) => setEndDate(e.target.value)}
            />
          </div>
        </div>
        <div className="flex pt-3">
          <button
            className="border border-lime-400  rounded-md w-52 py-2 px-3 hover:bg-lime-400"
            onClick={addData}
          >
            Хадгалах
          </button>
        </div>
      </div>
    </div>
  );
};

export default CreateJob;
