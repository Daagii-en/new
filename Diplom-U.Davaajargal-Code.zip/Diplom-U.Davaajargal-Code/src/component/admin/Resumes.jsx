import React, { useEffect, useState } from "react";
import LineB from "../container/lineB/LineB";
// import { useTheme } from "@mui/material/styles";
import axios from "axios";
import zurag from "./zurag.png";
import { Avatar, Badge } from "@mui/material";
import Card from "@mui/material/Card";
import CardMedia from "@mui/material/CardMedia";
import { Email } from "@mui/icons-material";

const Resumes = (props: TablePaginationActionsProps) => {
  const [resumes, setResumes] = useState([]);
  const [error, setError] = useState(null);
  const [info, setInfo] = useState(false);
  let [num, setNum] = useState(null);
  // useEffect(() => {
  //   axios
  //     .get("http://localhost:8000/api/resumes", {
  //       headers: {
  //         authorization: `Bearer ${localStorage.getItem("token")}`,
  //       },
  //     })
  //     .then((result) => setResumes(result.data.data))
  //     .catch((err) => setError(err.response));
  // });
  // Avoid a layout jump when reaching the last page with empty rows.
  const handleInfo = (i) => {
    setInfo(true);
    setNum(i);
  };
  const handleSelect = (e) => {
    const { name, value } = e.target;
    if (value === "") {
      axios
        .get("http://localhost:8000/api/resumes", {
          headers: {
            authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        })
        .then((result) => setResumes(result.data.data))
        .catch((err) => setError(err.response));
    } else {
      axios
        .get(
          `http://localhost:8000/api/resumes?education.${name}=${e.target.value}`,
          {
            headers: {
              authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          }
        )
        .then((result) => setResumes(result.data.data))
        .catch((err) => setError(err.response));
    }
  };
  const handleSelectTime = (e) => {
    const { name, value } = e.target;
    if (value === "") {
      axios
        .get("http://localhost:8000/api/resumes", {
          headers: {
            authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        })
        .then((result) => setResumes(result.data.data))
        .catch((err) => setError(err.response));
    } else {
      axios
        .get(
          `http://localhost:8000/api/resumes?desiredjob.${name}=${e.target.value}`,
          {
            headers: {
              authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          }
        )
        .then((result) => setResumes(result.data.data))
        .catch((err) => setError(err.response));
    }
  };
  const handleResumeDelete = (userId) => {
    console.log("userID====", userId);
    axios
      .delete(`http://localhost:8000/api/resumes/${userId}/data`, {
        headers: {
          authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      })
      .then((result) => alert("Хэрэглэгчийн мэдээлэл амжилттай устлаа."))
      .catch((err) => setError(err.response));
  };
  return (
    <div className=" h-full    space-y-4 md:p-10 p-3  text-xs">
      <div className="text-xl font-bold ">Анкет шалгах</div>
      <LineB></LineB>
      <div className="flex justify-evenly">
        <div>
          {" "}
          <label className="mr-2">Боловсролын зэрэг</label>
          <select
            name="degree"
            onChange={(e) => handleSelect(e)}
            // onChange={(e) => handleChangeEdu(e, i)}
            className="p-2  border border-yellow-500 rounded"
          >
            <option value={""}>Сонгоно уу</option>
            <option value={""}>Бүх анкет харах</option>
            <option value={"Ахлах боловсрол"}>Ахлах боловсрол</option>
            <option value={"Бакалавр "}>Бакалавр </option>
            <option value={"Магистр"}>Магистр</option>
            <option value={"Доктор"}>Доктор</option>
            <option value={"Пропессор"}>Пропессор</option>
            <option value={"Сертификат"}>Сертификат</option>
          </select>
        </div>
        <div>
          <label className="mr-2"> Ажиллах цаг</label>
          <select
            name="worktime"
            onChange={(e) => handleSelectTime(e)}
            // onChange={(e) => handleChangeEdu(e, i)}
            className="p-2 border  border-yellow-500 rounded"
          >
            <option value={""}>Сонгоно уу</option>
            <option value={""}>Бүх анкет харах</option>
            <option value={"Бүтэн цаг"}>Бүтэн цаг</option>
            <option value={"Хагас цаг"}>Хагас цаг</option>
          </select>
        </div>
      </div>
      <div className="flex w-full space-x-3 ">
        <div className="space-y-3 w-1/2">
          {resumes.map((e, i) => {
            return (
              <div key={i} className=" rounded-md border p-2 bg-slate-100 ">
                <div className="">
                  <div className="text-xs ">
                    Ажил горилогч:{" "}
                    {e.general.lastname + " " + e.general.firstname}
                  </div>
                  <div className="flex">
                    <button
                      className="border border-lime-400  rounded-md w-52 py-2 px-3 hover:bg-lime-400 text-sx"
                      onClick={(e) => handleInfo(i)}
                    >
                      Мэдээлэл харах
                    </button>
                  </div>
                </div>

                {/* {handleInfo()}; */}
              </div>
            );
          })}
        </div>
        <div className="rounded-md border p-6 bg-slate-100 w-full">
          {info ? (
            <div className="rounded-md border p-6 bg-slate-100 ">
              <div className="w-1/2">
                {/* <Card className="photo_container" sx={{ maxWidth: 345 }}>
                  <CardMedia
                    component="img"
                    height="25" 
                    // image={"../images/" + resumes[num].createUser.photo}
                    // image={url(`../images/${resumes[num].createUser.photo}`)}
                    alt="user_photo"
                  />
                </Card> */}
                {/* { resumes[num].createUser.photo && 
                  import.meta {zur} from `../images/${resumes[num].createUser.photo}`
                } */}
                <Avatar
                  alt="Remy Sharp"
                  src={zurag}
                  // src={`../../../public/uploads/${resumes[num].createUser.photo}`}
                />
                {resumes[num].createUser.photo}
              </div>
              <div>
                <b>Ерөнхий мэдээлэл</b>
                <ul className="pl-3">
                  <li>Миний тухай: {resumes[num].general.summary}</li>
                  <li>
                    Нэр:{" "}
                    {resumes[num].general.lastname +
                      " овогтой " +
                      resumes[num].general.firstname}
                  </li>
                  <li>
                    Төрсөн огноо: {resumes[num].general.birthdate.split("T")[0]}
                  </li>
                  <li>Нас: {resumes[num].general.age}</li>
                  <li>Хүйс: {resumes[num].general.gender}</li>
                </ul>
              </div>
              <div>
                <b>Ажил</b>
                <ul className="pl-3">
                  <li>Ажил: {resumes[num].desiredjob.job.name}</li>
                  <li>Хүсэж буй цалин: {resumes[num].desiredjob.salary}</li>
                  <li>Ажиллах цаг: {resumes[num].desiredjob.worktime}</li>
                </ul>
              </div>
              <div>
                <b>Холбоо барих</b>
                <ul className="pl-3">
                  <li>Имэйл: {resumes[num].contact.email}</li>
                  <li>Утас: {resumes[num].contact.phone}</li>
                  <li>Хаяг: {resumes[num].contact.address}</li>
                </ul>
              </div>
              <div>
                <b>Боловсрол:</b>{" "}
                {resumes[num].education.map((e) => {
                  return (
                    <ul className="pl-3 border rounded border-gray-950 p-2 mb-1">
                      {" "}
                      <li>Байгууллага: {e.institution}</li>
                      <li>Сургуулийн нэр: {e.schoolName}</li>
                      <li>Элссэн огноо: {e.startDate}</li>
                      <li>Төгссөн огноо: {e.endDate}</li>
                      <li>Зэрэг: {e.degree}</li>
                      <li>Голч: {e.gpa}</li>
                    </ul>
                  );
                })}
              </div>
              <div>
                <b>Ур чадвар</b>
                {resumes[num].skills.map((e) => {
                  return (
                    <ul className="pl-3 border rounded border-gray-950 p-2 mb-1">
                      {" "}
                      <li>Төрөл: {e.name}</li>
                      <li>Түвшин: {e.level}</li>
                    </ul>
                  );
                })}
              </div>
              <div>
                <b>Хэлний мэдлэг</b>
                {resumes[num].language.map((e) => {
                  return (
                    <ul className="pl-3 border rounded border-gray-950 p-2 mb-1">
                      {" "}
                      <li>Хэл: {e.name}</li>
                      <li>Түвшин: {e.level}</li>
                    </ul>
                  );
                })}
              </div>
              <div className="m-1 flex justify-evenly">
                {" "}
                <button className="border border-lime-400  rounded-md w-48 py-2 px-3 hover:bg-lime-400">
                  Хариу илгээх
                </button>{" "}
                <button
                  onClick={(e) =>
                    handleResumeDelete(resumes[num].createUser._id)
                  }
                  className="border border-red-500 rounded-md w-48 py-2 px-3 hover:bg-red-500"
                >
                  Устгах
                </button>{" "}
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
};

export default Resumes;
