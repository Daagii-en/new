import React from "react";
import "./career.css";
export default function Spinner() {
  return <div className="loader"></div>;
}
