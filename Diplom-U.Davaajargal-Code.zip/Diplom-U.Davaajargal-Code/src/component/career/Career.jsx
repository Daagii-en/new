import { Button } from "@mui/material";

import React, { Component } from "react";
import { Link } from "react-router-dom";
import LineB from "../container/lineB/LineB";
// import storaimg from "./b390c0911497c3ac8467bc87cc689186.jpg";
import storaimg from "../container/home/temp.png";

import axios from "axios";
import Spinner from "./index";

export default class Career extends Component {
  state = {
    careers: [],
    error: null,
    loading: false,
  };
  componentDidMount = () => {
    this.setState({ loading: true });
    axios
      .get("http://localhost:8000/api/careers")
      .then((result) =>
        this.setState({ careers: result.data.data, loading: false })
      )
      .catch((err) => this.setState({ error: err.response, loading: false }));
  };

  render() {
    if (this.state.error) {
      return <div className="bg-yellow-300 p-2">{this.state.error}</div>;
    }
    return (
      <div id="career" className="bg-black-50 pb-10 pt-12 md:pt-16">
        <div className="w-4/5  mx-auto">
          <LineB></LineB>
          <h1
            data-aos="fade-up"
            data-aos-anchor-placement="top-bottom"
            className="text-xl md:text-2xl font-bold  mt-5"
          >
            Нээлттэй ажлын байр
          </h1>
          <div className=" text-xs md:text-lg md:flex md:space-x-5 mt-5">
            <div className="">
              <div className="mb-5">
                Та нээлттэй ажлын байранд тавигдах шаардлагыг хангаж байна гэж
                үзвэл анкетаа бидэнд илгээнэ үү.
              </div>
              {this.state.loading && <Spinner />}
              <div className="space-y-3">
                {this.state.careers.map((e, i) => {
                  return (
                    <div
                      key={i}
                      className=" w-full space-y-3 p-4 rounded-md box-border bg-gray-100 opacity-75"
                    >
                      <div className="">
                        <div className="pb-2 text-bold">
                          Ажлын байр:{" " + e.name}
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <div>Чадвар:</div>
                        <div>
                          <ul>
                            {/* {e.skill.map()} */}
                            {e.skill.map((el, i) => {
                              return <li key={i}> - {el}</li>;
                            })}
                          </ul>
                        </div>
                      </div>
                      <div className="md:flex justify-between pb-3">
                        <div className="text-sx">
                          Огноо: {" " + e.createdAt.split("T")[0]}
                        </div>
                        <div className="text-sx">
                          Сүүлийн хугацаа: {" " + e.endDate.split("T")[0]}
                        </div>
                      </div>
                      {!localStorage.getItem("token") ? (
                        <Link to="/users/signin">
                          <Button className="" variant="contained">
                            Анкет илгээх
                          </Button>
                        </Link>
                      ) : localStorage.getItem("role") === "user" ? (
                        <Link to="/users">
                          <Button variant="contained">Анкет илгээх</Button>
                        </Link>
                      ) : (
                        <Link to="/admin">
                          <Button className="" variant="contained">
                            Анкет илгээх
                          </Button>
                        </Link>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="w-full md:w-3/5 mt-3 md:mt-0">
              <img src={storaimg} alt="zuragg" className="" />
            </div>
          </div>
        </div>
      </div>
    );
  }
}
