import React, { useState } from "react";
import logo from "../../photos/logo.svg";
import Navbar from "../navbar/Navbar";
import "./header.css";
import { Link } from "react-scroll";
import { Link as LinkRoute } from "react-router-dom";
export default function Header() {
  const [click, setClick] = useState(false);
  const handleClick = () => {
    setClick(!click);
  };

  return (
    <div className="mt-0">
      <div className="header bg-white border-b border-amber-400 bg-opacity-95 fixed w-full font-semibold">
        <div className=" md:w-11/12  container md:mx-auto md:p-4  flex justify-between items-center opacity-95 ">
          <div className=" w-full md:w-auto justify-between items-center">
            <div className=" p-3 md:p-0 flex justify-between items-center ">
              <Link
                to="home"
                spy={true}
                smooth={true}
                offset={100}
                duration={1000}
              >
                <LinkRoute to="/">
                  <img
                    src={logo}
                    alt="storalogo"
                    className="w-12  md:w-24 transition duration-500 ease-in-out transform text-black-500 hover:text-yellow-500  hover:scale-95 cursor-pointer"
                  />
                </LinkRoute>
              </Link>

              <label
                className="cursor-pointer md:hidden block mr-0 pr-0"
                onClick={handleClick}
              >
                <svg
                  className="fill-current text-indigo-900"
                  xmlns="http://www.w3.org/2000/svg"
                  width="20"
                  height="20"
                  viewBox="0 0 20 20"
                >
                  <title>menu</title>
                  <path d="M0 3h20v2H0V3zm0 6h20v2H0V9zm0 6h20v2H0v-2z"></path>
                </svg>
              </label>
            </div>
            {click ? <Navbar click={handleClick}></Navbar> : null}
          </div>

          <div
            className="hidden md:visible changeNav md:flex md:items-center w-auto  order-5 md:order-1"
            id="menu"
          >
            <nav>
              <ul className=" md:flex items-center justify-between md:text-sm lg:text-base md:font-extrabold   pt-4 md:pt-0 space-x-4 md:space-x-8 ">
                <li>
                  <Link
                    to="about"
                    spy={true}
                    smooth={true}
                    offset={100}
                    duration={1000}
                    className="inline-block no-underline transition  ease-in-out hover:text-indigo-900 transform  hover:scale-100 font-semibold  lg:-ml-2 cursor-pointer "
                  >
                    <LinkRoute to="/">Бидний тухай</LinkRoute>
                  </Link>
                </li>
                <li>
                  <Link
                    to="team"
                    spy={true}
                    smooth={true}
                    offset={100}
                    duration={1000}
                    className="inline-block no-underline transition ease-in-out hover:text-indigo-900 transform hover:scale-95 font-semibold cursor-pointer  lg:-ml-2"
                  >
                    <LinkRoute to="/">Манай баг</LinkRoute>
                  </Link>
                </li>
                <li>
                  <Link
                    to="partner"
                    spy={true}
                    smooth={true}
                    offset={100}
                    duration={1000}
                    className="inline-block no-underline transition ease-in-out hover:text-indigo-900 transform hover:scale-95 font-semibold  cursor-pointer lg:-ml-2"
                  >
                    <LinkRoute to="/">Хамтрагч</LinkRoute>
                  </Link>
                </li>
                <li>
                  <Link
                    to="contact"
                    spy={true}
                    smooth={true}
                    offset={100}
                    duration={1000}
                    className="inline-block no-underline transition ease-in-out hover:text-indigo-900 transform  hover:scale-95 cursor-pointer font-semibold lg:-ml-2"
                  >
                    <LinkRoute to="/">Холбоо барих</LinkRoute>
                  </Link>
                </li>
                <li>
                  <LinkRoute
                    to="/careers"
                    className="inline-block no-underline transition ease-in-out hover:text-indigo-900 transform hover:scale-95 font-semibold cursor-pointer bg-yellow-400 p-2  lg:-ml-2"
                  >
                    Нээлттэй ажил
                  </LinkRoute>
                </li>
                {/* <li>
                  <a
                    className="inline-block no-underline transition ease-in-out hover:text-indigo-900 transform  hover:scale-95 cursor-pointer font-semibold lg:-ml-2"
                    href="https://www.stora.mn/"
                    target="_blank"
                    rel="noreferrer"
                  >
                    Стора шоп
                  </a>
                </li> */}

                <li>
                  {!localStorage.getItem("token") ? (
                    <LinkRoute
                      to="/users/signin"
                      className="inline-block no-underline transition ease-in-out  text-white transform hover:scale-95 font-semibold cursor-pointer bg-indigo-900 px-3 py-2  lg:-ml-2"
                    >
                      Нэвтрэх
                    </LinkRoute>
                  ) : localStorage.getItem("role") === "user" ? (
                    <LinkRoute
                      to="/users"
                      className="inline-block no-underline transition ease-in-out text-white transform hover:scale-95 font-semibold cursor-pointer  bg-indigo-800 px-3 py-2  lg:-ml-2"
                    >
                      {localStorage.getItem("username")}
                    </LinkRoute>
                  ) : (
                    <LinkRoute
                      to="/admin"
                      className="inline-block no-underline transition ease-in-out  text-white transform hover:scale-95 font-semibold cursor-pointer bg-indigo-800 px-3 py-2  lg:-ml-2"
                    >
                      {localStorage.getItem("username")}
                    </LinkRoute>
                  )}
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </div>
  );
}
