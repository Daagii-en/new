import React, { useState } from "react";
import LineB from "../container/lineB/LineB";
import { Input } from "@mui/material";
import axios from "axios";

const ChangePassword = () => {
  const [password, setPassword] = useState(null);
  const [newPassword, setNewPass] = useState(null);
  const [validPass, setValid] = useState(null);
  const [error, setError] = useState(null);

  const handleValidPass = (e) => {
    setValid(e.target.value);
    if (newPassword === validPass) {
      setError(true);
    } else {
      setError(false);
    }
  };
  const handleDataSave = () => {
    axios
      .put(
        `http://localhost:8000/api/users/${localStorage.getItem(
          "userId"
        )}/change-password`,
        {
          password: password,
          newPassword: newPassword,
        },
        {
          headers: {
            authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      )
      .then((result) => {
        // console.log(result.data);
        alert("Амжилттай нууц үг солиллоо...");
      })
      .catch((err) => {
        setError(err.response.data.error.message);
        alert("Алдаа гарлаа та дахин оролдоно уу...");
      });
  };
  return (
    <div className=" h-full    space-y-4 p-3 md:p-10 text-sx text-xs">
      <div className="text-xl font-bold ">Нууц үг солих</div>
      <LineB></LineB>
      <div className="space-y-3 rounded-md border p-6 bg-slate-100">
        <div className="space-y-3">
          <div>
            <p>Одоогийн нууц үг:</p>
            <Input
              type="password"
              onChange={(e) => {
                setPassword(e.target.value);
              }}
            ></Input>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2">
            <div>
              <p>Шинэ нууц үгээ оруулна уу:</p>
              <Input
                type="password"
                placeholder="нууц үг"
                onChange={(e) => {
                  setNewPass(e.target.value);
                }}
              ></Input>
            </div>
            <div>
              {/* {!error ? <></> : <div>Нууц үгээ зөв оруулна уу.</div>} */}
              <p>Давтан оруулна уу:</p>
              <Input
                type="password"
                placeholder="нууц үг"
                onChange={handleValidPass}
              ></Input>
            </div>
          </div>
        </div>
        <div className="flex pt-3">
          <button
            onClick={handleDataSave}
            className="border border-lime-400  rounded-md w-52 py-2 px-3 hover:bg-lime-400"
          >
            Нууц үг солих
          </button>
        </div>
      </div>
    </div>
  );
};
export default ChangePassword;
