// import React, { Component } from 'react'
// import LineB from "../container/lineB/LineB";
// import { IconButton, Input, TextField } from "@mui/material";
// import DeleteIcon from "@mui/icons-material/Delete";
// import AddCircleOutlineRoundedIcon from "@mui/icons-material/AddCircleOutlineRounded";
// import FileUploadIcon from "@mui/icons-material/FileUpload";
// import axios from "axios";
// import Autocomplete from "@mui/material/Autocomplete";
// import General from "./Form/General";
// import Contact from "./Form/Contact";
// import Desiredjob from "./Form/Desiredjob";
// import Education from "./Form/Education";
// import Experiences from "./Form/Experiences";
// import Family from "./Form/Family";
// import Language from "./Form/Language";
// import Skills from "./Form/Skills";
// import { now } from "mongoose";
// export default class ClassForm extends Component {
//   constructor(props){
//     this.state = {
//       general:{
//         summary: null,
//         lastname: null,
//         firstname: null,
//         birthdate: null,
//         age: null,
//         gender: null,
//         register: null,
//       },
//       contact:{phone: null,
//         email: null,
//         address: null,},
//         desiredjob:{
//           job: null,
//     salary: null,
//     worktime: null,
//         },
//         education:[{
//           institution: null,
//           schoolName: null,
//           degree: null,
//           gpa: null,
//           startDate: null,
//           endDate: null,
//           location: null,
//           profession: null,
//         }],
// experiences:[{
//   position: null,
//       company: null,
//       location: null,
//       startDate: null,
//       endDate: null,
// }],
// family:[
//   { name: null, who: null, age: null, positionF: null, phone: null },
// ],
// language:[{ name: null, level: null }],
// skills:[{ name: null, level: null }],
// photo:"no-photo.jpg",
// cv:[null],
// error:null,
// userData:{},
//     }

//   }
//   // let [userData, setUserData] = useState({});
//   // let [careers, setCareers] = useState([{ label: "a" }, { label: "b" }]);

//   // const [cv, setFile] = useState(null);

//   //-------------------
//   const addObjectEdu = (e) => {
//     this.setState({...education,education:{institution: null,
//       schoolName: null,
//       degree: null,
//       rate: null,
//       startDate: null,
//       endDate: null,
//       location: null,
//       profession: null}})
//     // setEducation([
//     //   ...education,
//     //   {
//     //     institution: null,
//     //     schoolName: null,
//     //     degree: null,
//     //     rate: null,
//     //     startDate: null,
//     //     endDate: null,
//     //     location: null,
//     //     profession: null,
//     //   },
//     // ]);
//   };
//   const handleDeleteEdu = (i) => {
//     const deleteVal =  this.state.education //[...education];
//     deleteVal.splice(i, 1);
//     this.setState(education:deleteVal);
//     // setEducation(deleteVal);
//   };
//   const handleChangeEdu = (e, i) => {
//     const { name, value } = e.target;

//     const changeVal =this.state.education; // [...education];
//     changeVal[i][name] = value;
//     this.setState(education:changeVal);
//     // setEducation(changeVal);
//   };
//   //----------------------------
//   const addObjectExp = (e) => {
//     setExperiences([
//       ...experiences,
//       {
//         position: null,
//         company: null,
//         location: null,
//         startDate: null,
//         endDate: null,
//       },
//     ]);
//   };
//   const handleDeleteExp = (i) => {
//     const deleteVal = [...experiences];
//     deleteVal.splice(i, 1);
//     setExperiences(deleteVal);
//   };
//   const handleChangeExp = (e, i) => {
//     const { name, value } = e.target;

//     const changeVal = [...experiences];
//     changeVal[i][name] = value;
//     setExperiences(changeVal);
//   };
//   // //---------------------------------
//   // const addObjectFam = (e) => {
//   //   setFamily([
//   //     ...family,
//   //     { name: null, who: null, age: null, positionF: null, phone: null },
//   //   ]);
//   // };
//   // const handleDeleteFam = (i) => {
//   //   const deleteVal = [...family];
//   //   deleteVal.splice(i, 1);
//   //   setFamily(deleteVal);
//   // };
//   // const handleChangeFam = (e, i) => {
//   //   const { name, value } = e.target;

//   //   const changeVal = [...family];
//   //   changeVal[i][name] = value;
//   //   setFamily(changeVal);
//   // };
//   // //-----------------------
//   // const addObjectLan = (e) => {
//   //   setLanguage([...language, { name: null, level: null }]);
//   // };
//   // const handleDeleteLan = (i) => {
//   //   const deleteVal = [...language];
//   //   deleteVal.splice(i, 1);
//   //   setLanguage(deleteVal);
//   // };
//   // const handleChangeLan = (e, i) => {
//   //   const { name, value } = e.target;

//   //   const changeVal = [...language];
//   //   changeVal[i][name] = value;
//   //   setLanguage(changeVal);
//   // };
//   //-------------------------
//   // const addSkillSki = (e) => {
//   //   setSkills([...skills, { name: null, level: null }]);
//   // };
//   // const handleDeleteSki = (i) => {
//   //   const deleteVal = [...skills];
//   //   deleteVal.splice(i, 1);
//   //   setSkills(deleteVal);
//   // };
//   // const handleChangeSki = (e, i) => {
//   //   const { name, value } = e.target;

//   //   const changeSkill = [...skills];
//   //   changeSkill[i][name] = value;
//   //   setSkills(changeSkill);
//   // };
//   //-----------------
//   const handleFileUpload = (event) => {
//     // this.setState(file)
//     // setFile(event.target.files[0]);
//   };

//   let handleDataSave = () => {
//     axios
//       .put(
//         `http://localhost:8000/api/resumes/${localStorage.getItem(
//           "userId"
//         )}/data`,
//         {
//           this.state,
//           contact,
//           desiredjob,
//           education,
//           experiences,
//           skills,
//           language,
//           family,
//           photo,
//           updatedAt: Date.now(),
//         },
//         {
//           headers: {
//             authorization: `Bearer ${localStorage.getItem("token")}`,
//             "Content-Type": "application/json",
//           },
//         }
//       )
//       .then((result) => {
//         setUserData(result.data.data);
//         alert("Updated...");
//         console.log("------->", result.data.data);
//       })
//       .catch((err) => setError(err.response));
//   };
//   let handleDataCreate = () => {
//     console.log("==>");
//     axios
//       .post(
//         `http://localhost:8000/api/resumes/${localStorage.getItem(
//           "userId"
//         )}/data`,
//         {
//           general,
//           contact,
//           desiredjob,
//           education,
//           experiences,
//           skills,
//           language,
//           family,
//           photo,
//         },
//         {
//           headers: {
//             authorization: `Bearer ${localStorage.getItem("token")}`,
//             "Content-Type": "application/json",
//           },
//         }
//       )
//       .then((result) => {
//         setUserData(result.data.data);
//         alert("Created...");
//         console.log("------->", result.data.data);
//       })
//       .catch((err) => setError(err.response));
//   };

//   render() {
//     return (
//       <div className=" h-fit sm:border-l sm:border-amber-400 w-full md:w-3/4 space-y-4 p-3  md:p-10 text-sx text-xs">
//         <div className="text-xl font-bold ">Миний анкет</div>
//         <LineB></LineB>
//         <>
//           <div className="space-y-3 rounded-md border p-6 bg-slate-100">
//             <p className="text-base font-semibold">
//               Ерөнхий мэдээлэл <span className="text-red-600">*</span>
//             </p>
//             <div className="space-y-3">
//               <div>
//                 <p>Миний тухай:</p>
//                 <TextField
//                   id="outlined-basic"
//                   label=""
//                   name="summary"
//                   onChange={(e) => {
//                     setGeneral({ ...general, summary: e.target.value });
//                   }}
//                   className="w-full"
//                   variant="outlined"
//                   value={general.summary}
//                 ></TextField>
//               </div>
//               <div className="space-y-2 grid grid-cols-1 md:grid-cols-2">
//                 <div>
//                   <p>Эцэг/эхийн нэр:</p>
//                   <Input
//                     placeholder="эцэг/эхийн нэр"
//                     value={general.lastname}
//                     onChange={(e) => {
//                       setGeneral({ ...general, lastname: e.target.value });
//                     }}
//                   />
//                 </div>
//                 <div>
//                   <p>Өөрийн нэр:</p>
//                   <Input
//                     placeholder="өөрийн нэр"
//                     onChange={(e) => {
//                       setGeneral({ ...general, firstname: e.target.value });
//                     }}
//                     value={general.firstname}
//                   ></Input>
//                 </div>
//                 <div>
//                   <p>Регистрийн дугаар:</p>
//                   <Input
//                     placeholder="регистрийн дугаар"
//                     onChange={(e) => {
//                       setGeneral({ ...general, register: e.target.value });
//                     }}
//                     value={general.register}
//                   ></Input>
//                 </div>
//                 <div>
//                   <p>Хүйс:</p>
//                   <Input
//                     placeholder="хүйс"
//                     onChange={(e) => {
//                       setGeneral({ ...general, gender: e.target.value });
//                     }}
//                     value={general.gender}
//                   ></Input>
//                 </div>
//                 <div>
//                   <p>Төрсөн огноо:</p>
//                   <Input
//                     placeholder="төрсөн он сар өдөр"
//                     onChange={(e) => {
//                       setGeneral({ ...general, birthdate: e.target.value });
//                     }}
//                     value={general.birthdate}
//                   ></Input>
//                 </div>
//                 <div>
//                   <p>Нас:</p>
//                   <Input
//                     placeholder="нас"
//                     onChange={(e) => {
//                       setGeneral({ ...general, age: e.target.value });
//                     }}
//                     value={general.age}
//                   ></Input>
//                 </div>
//               </div>
//             </div>
//           </div>
//           <div className="space-y-3 rounded-md border p-6 bg-slate-100">
//             <p className="text-base font-semibold">
//               Холбоо барих мэдээлэл <span className="text-red-600">*</span>
//             </p>
//             <div className="space-y-3">
//               <div className=" space-y-2 grid grid-cols-1 md:grid-cols-2">
//                 <div>
//                   <p>Утасны дугаар:</p>
//                   <Input
//                     placeholder="утасны дугаар"
//                     onChange={(e) => {
//                       setContact({ ...contact, phone: e.target.value });
//                     }}
//                     value={contact.phone}
//                   ></Input>
//                 </div>
//                 <div>
//                   <p>Цахим хаяг:</p>
//                   <Input
//                     placeholder="цахим хаяг"
//                     onChange={(e) => {
//                       setContact({ ...contact, email: e.target.value });
//                     }}
//                     value={contact.email}
//                   ></Input>
//                 </div>
//                 <div>
//                   <p>Гэрийн хаяг:</p>
//                   <Input
//                     placeholder="гэрийн хаяг"
//                     onChange={(e) => {
//                       setContact({ ...contact, address: e.target.value });
//                     }}
//                     value={contact.address}
//                   ></Input>
//                 </div>
//               </div>
//             </div>
//           </div>
//           <div className="space-y-3 rounded-md border p-6 bg-slate-100">
//             <p className="text-base font-semibold">
//               Таны хүсэж буй ажил<span className="text-red-600">*</span>
//             </p>
//             <div className="space-y-3">
//               <div className=" space-y-2 grid grid-cols-1 md:grid-cols-2">
//                 <div>
//                   <p>Ажил:</p>
//                   <Input
//                     placeholder="ажил"
//                     onChange={(e) => {
//                       setDesiredjob({ ...desiredjob, job: e.target.value });
//                     }}
//                     value={desiredjob.job}
//                   ></Input>
//                 </div>
//                 <div>
//                   <p>Цалин:</p>
//                   <Input
//                     placeholder="цалин"
//                     onChange={(e) => {
//                       setDesiredjob({ ...desiredjob, salary: e.target.value });
//                     }}
//                     value={desiredjob.salary}
//                   ></Input>
//                 </div>
//                 <div>
//                   <p>Ажлын цаг:</p>
//                   <Input
//                     placeholder="ажлын цаг"
//                     onChange={(e) => {
//                       setDesiredjob({ ...desiredjob, worktime: e.target.value });
//                     }}
//                     value={desiredjob.worktime}
//                   ></Input>
//                 </div>
//               </div>
//             </div>
//           </div>
//           <div className="space-y-3 rounded-md border p-6 bg-slate-100">
//             <p className="text-base font-semibold">
//               Боловсрол <span className="text-red-600">*</span>
//             </p>
//             <div className="space-y-3">
//               {education.map((e, i) => {
//                 return (
//                   <div className="md:flex md:justify-between rounded-md bg-slate-200 border p-6">
//                     <div
//                       key={i}
//                       className="space-y-2 md:space-y-0 md:space-x-2 grid grid-cols-1 md:grid-cols-2"
//                     >
//                       <div>
//                         <p>Байгууллага:</p>
//                         <Input
//                           key={i}
//                           name="institution"
//                           onChange={(e) => handleChangeEdu(e, i)}
//                           placeholder="байгууллага"
//                           value={e.institution}
//                         ></Input>
//                       </div>
//                       <div>
//                         <p>Сургууль:</p>
//                         <Input
//                           key={i}
//                           name="schoolName"
//                           onChange={(e) => handleChangeEdu(e, i)}
//                           placeholder="сургууль"
//                           value={e.schoolName}
//                         ></Input>
//                       </div>
//                       <div>
//                         <p>Мэргэжил:</p>
//                         <Input
//                           placeholder="мэргэжил"
//                           key={i}
//                           name="profession"
//                           onChange={(e) => handleChangeEdu(e, i)}
//                           value={e.profession}
//                         ></Input>
//                       </div>
//                       <div>
//                         <p>Боловсролын зэрэг:</p>
//                         <Input
//                           placeholder="зэрэг"
//                           key={i}
//                           name="degree"
//                           onChange={(e) => handleChangeEdu(e, i)}
//                           value={e.degree}
//                         ></Input>
//                       </div>
//                       <div>
//                         <p>Голч дүн:</p>
//                         <Input
//                           placeholder="голч"
//                           key={i}
//                           name="gpa"
//                           onChange={(e) => handleChangeEdu(e, i)}
//                           value={e.gpa}
//                         ></Input>
//                       </div>
//                       <div>
//                         <p>Элссэн он:</p>
//                         <Input
//                           placeholder="огноо"
//                           key={i}
//                           name="startDate"
//                           onChange={(e) => handleChangeEdu(e, i)}
//                           value={e.startDate}
//                         ></Input>
//                       </div>
//                       <div>
//                         <p>Төгссөн он:</p>
//                         <Input
//                           placeholder="огноо"
//                           key={i}
//                           name="endDate"
//                           onChange={(e) => handleChangeEdu(e, i)}
//                           value={e.endDate}
//                         ></Input>
//                       </div>
//                       <div>
//                         <p>Байршил:</p>
//                         <Input
//                           placeholder="хаана"
//                           key={i}
//                           name="location"
//                           onChange={(e) => handleChangeEdu(e, i)}
//                           value={e.location}
//                         ></Input>
//                       </div>
//                     </div>
//                     <button
//                       className="bg-inherit  rounded p-2 hover:bg-red-300"
//                       onClick={() => handleDeleteEdu(i)}
//                     >
//                       <DeleteIcon />
//                     </button>
//                   </div>
//                 );
//               })}
//               <button
//                 className="bg-inherit rounded mt-2 p-2 hover:bg-lime-500"
//                 onClick={addObjectEdu}
//               >
//                 Нэмэх <AddCircleOutlineRoundedIcon />
//               </button>
//             </div>
//           </div>
//           <div className="space-y-3 rounded-md border p-6 bg-slate-100">
//             <p className="text-base font-semibold">Ажлын туршлага </p>
//             <div className="space-y-3">
//               {experiences.map((e, i) => {
//                 return (
//                   <div className="md:flex md:justify-between rounded-md bg-slate-200 border p-6">
//                     <div
//                       key={i}
//                       className="space-y-3 md:space-y-0 md:space-x-5 grid grid-cols-1 md:grid-cols-2"
//                     >
//                       <div>
//                         <p>Байгууллагын нэр:</p>
//                         <Input
//                           key={i}
//                           name="company"
//                           onChange={(e) => handleChangeExp(e, i)}
//                           placeholder="байгууллагын нэр"
//                           value={e.company}
//                         ></Input>
//                       </div>
//                       <div>
//                         <p>Албан тушаал, Мэргэжил:</p>
//                         <Input
//                           key={i}
//                           name="position"
//                           onChange={(e) => handleChangeExp(e, i)}
//                           placeholder="албан тушаал, мэргэжил"
//                           value={e.position}
//                         ></Input>
//                       </div>
//                       <div>
//                         <p>Ажилд орсон огноо:</p>
//                         <Input
//                           key={i}
//                           name="startDate"
//                           onChange={(e) => handleChangeExp(e, i)}
//                           placeholder="огноо"
//                           value={e.startDate}
//                         ></Input>
//                       </div>
//                       <div>
//                         <p>Ажлаас гарсан огноо:</p>
//                         <Input
//                           key={i}
//                           name="endDate"
//                           onChange={(e) => handleChangeExp(e, i)}
//                           placeholder="огноо"
//                           value={e.endDate}
//                         ></Input>
//                       </div>
//                       <div>
//                         <p>Байршил:</p>
//                         <Input
//                           key={i}
//                           name="location"
//                           onChange={(e) => handleChangeExp(e, i)}
//                           placeholder="хаана?"
//                           value={e.location}
//                         ></Input>
//                       </div>
//                     </div>
//                     <button
//                       className="bg-inherit  rounded p-2 hover:bg-red-300"
//                       onClick={() => handleDeleteExp(i)}
//                     >
//                       <DeleteIcon />
//                     </button>
//                   </div>
//                 );
//               })}
//               <button
//                 className="bg-inherit rounded mt-2 p-2 hover:bg-lime-500"
//                 onClick={addObjectExp}
//               >
//                 Нэмэх <AddCircleOutlineRoundedIcon />
//               </button>
//             </div>
//           </div>
//           <div className="space-y-3 rounded-md border p-6 bg-slate-100">
//             <p className="text-base font-semibold">Гэр бүлийн мэдээлэл </p>
//             <div className="space-y-3">
//               {family.map((e, i) => {
//                 return (
//                   <div className="md:flex md:justify-between rounded-md bg-slate-200 border p-6">
//                     <div
//                       key={i}
//                       className="space-y-2 md:space-y-0 md:space-x-2 grid grid-cols-1 md:grid-cols-2"
//                     >
//                       <div>
//                         <p>Нэр:</p>
//                         <Input
//                           key={i}
//                           name="name"
//                           onChange={(e) => handleChangeFam(e, i)}
//                           placeholder="нэр"
//                           value={e.name}
//                         ></Input>
//                       </div>
//                       <div>
//                         <p>Таны хэн болох:</p>
//                         <Input
//                           key={i}
//                           name="who"
//                           onChange={(e) => handleChangeFam(e, i)}
//                           placeholder="таны хэн болох"
//                           value={e.who}
//                         ></Input>
//                       </div>
//                       <div>
//                         <p>Нас:</p>
//                         <Input
//                           key={i}
//                           name="age"
//                           onChange={(e) => handleChangeFam(e, i)}
//                           placeholder="нас"
//                           value={e.age}
//                         ></Input>
//                       </div>
//                       <div>
//                         <p>Холбоо барих дугаар:</p>
//                         <Input
//                           key={i}
//                           name="phone"
//                           onChange={(e) => handleChangeFam(e, i)}
//                           placeholder="утасны дугаар"
//                           value={e.phone}
//                         ></Input>
//                       </div>
//                       <div>
//                         <p>Ажил/албан тушаал:</p>
//                         <Input
//                           key={i}
//                           name="positionF"
//                           onChange={(e) => handleChangeFam(e, i)}
//                           placeholder="ажил албан тушаал"
//                           value={e.positionF}
//                         ></Input>
//                       </div>
//                     </div>
//                     <button
//                       className="bg-inherit  rounded p-2 hover:bg-red-300"
//                       onClick={() => handleDeleteFam(i)}
//                     >
//                       <DeleteIcon />
//                     </button>
//                   </div>
//                 );
//               })}
//               <button
//                 className="bg-inherit rounded mt-2 p-2 hover:bg-lime-500"
//                 onClick={addObjectFam}
//               >
//                 Нэмэх <AddCircleOutlineRoundedIcon />
//               </button>
//             </div>
//           </div>
//           <div className="space-y-3 rounded-md border p-6 bg-slate-100">
//             <p className="text-base font-semibold">Гадаа хэлний мэдээлэл</p>
//             <div className="space-y-3">
//               {language.map((e, i) => {
//                 return (
//                   <div className="md:flex md:justify-between rounded-md bg-slate-200 border p-6">
//                     <div
//                       key={i}
//                       className="space-y-2 md:space-y-0 md:space-x-2 grid grid-cols-1 md:grid-cols-2"
//                     >
//                       <div>
//                         <p>Хэл:</p>
//                         <Input
//                           key={i}
//                           name="name"
//                           onChange={(e) => handleChangeLan(e, i)}
//                           placeholder="хэл"
//                           value={e.name}
//                         ></Input>
//                       </div>
//                       <div>
//                         <p>Түвшин:</p>
//                         <Input
//                           key={i}
//                           name="level"
//                           onChange={(e) => handleChangeLan(e, i)}
//                           placeholder="түвшин"
//                           value={e.level}
//                         ></Input>
//                       </div>
//                     </div>
//                     <button
//                       className="bg-inherit  rounded p-2 hover:bg-red-300"
//                       onClick={() => handleDeleteLan(i)}
//                     >
//                       <DeleteIcon />
//                     </button>
//                   </div>
//                 );
//               })}
//               <button
//                 className="bg-inherit rounded mt-2 p-2 hover:bg-lime-500"
//                 onClick={addObjectLan}
//               >
//                 Нэмэх <AddCircleOutlineRoundedIcon />
//               </button>
//             </div>
//           </div>
//           <div className="space-y-3 rounded-md border p-6 bg-slate-100">
//             <p className="text-base font-semibold">Ур чадварын мэдээлэл</p>
//             <div className="space-y-3">
//               {skills.map((e, i) => {
//                 return (
//                   <div className="md:flex md:justify-between rounded-md bg-slate-200 border p-6">
//                     <div
//                       key={i}
//                       className="space-y-2 md:space-y-0 md:space-x-2 grid grid-cols-1 md:grid-cols-2"
//                     >
//                       <div>
//                         <p>Төрөл:</p>
//                         <Input
//                           key={i}
//                           name="name"
//                           onChange={(e) => handleChangeSki(e, i)}
//                           placeholder="төрөл"
//                           value={e.name}
//                         ></Input>
//                       </div>
//                       <div>
//                         <p>Түвшин:</p>
//                         <Input
//                           key={i}
//                           name="level"
//                           onChange={(e) => handleChangeSki(e, i)}
//                           placeholder="түвшин"
//                           value={e.level}
//                         ></Input>
//                       </div>
//                     </div>
//                     <button
//                       className="bg-inherit  rounded p-2 hover:bg-red-300"
//                       onClick={() => handleDeleteSki(i)}
//                     >
//                       <DeleteIcon />
//                     </button>
//                   </div>
//                 );
//               })}
//               <button
//                 className="bg-inherit rounded mt-2 p-2 hover:bg-lime-500"
//                 onClick={addSkillSki}
//               >
//                 Ур чадвар нэмэх <AddCircleOutlineRoundedIcon />
//               </button>
//             </div>
//           </div>
//           {/* <General />
//           <Contact />
//           <Desiredjob />
//           <Education />
//           <Experiences />
//           <Family />
//           <Language />
//           <Skills /> */}
//           <div className="space-y-3 rounded-md border p-6 bg-slate-100">
//             <p className="text-base font-semibold">
//               CV, Resume, Cover Letter хавсаргах(PDF болон DOC,DOCX)
//             </p>
//             <div className="flex space-x-2">
//               <IconButton
//                 color="primary"
//                 aria-label="upload file"
//                 component="label"
//               >
//                 <input
//                   hidden
//                   type="file"
//                   id="resume"
//                   name="resume"
//                   accept=".pdf,.doc,.docx"
//                   onChange={handleFileUpload}
//                 />
//                 {/* <input  accept="text/pdf" type="file" /> */}
//                 <FileUploadIcon />
//               </IconButton>
//               {cv &&
//                 cv.map((e, i) => {
//                   return <div key={i}>{e}</div>;
//                 })}
//             </div>
//           </div>

//           <div className="flex space-x-5 pt-3">
//             {userData ? (
//               <button
//                 onClick={handleDataCreate}
//                 className="border border-lime-400  rounded-md w-52 py-2 px-3 hover:bg-lime-400"
//               >
//                 Хадгалах create
//               </button>
//             ) : (
//               <button
//                 onClick={handleDataSave}
//                 className="border border-lime-400  rounded-md w-52 py-2 px-3 hover:bg-lime-400"
//               >
//                 Хадгалах save
//               </button>
//             )}

//             <button
//               type="submit"
//               onClick={handleDataSave}
//               className="border border-lime-400 bg-lime-300  rounded-md w-52 py-2 px-3 hover:bg-lime-400"
//             >
//               Анкет илгээх
//             </button>
//           </div>
//         </>
//       </div>
//     );
//   }
// }
