import React, { useState } from "react";
import { Avatar, Badge, IconButton } from "@mui/material";
import TextSnippetIcon from "@mui/icons-material/TextSnippet";
import LogoutIcon from "@mui/icons-material/Logout";
import ManageAccountsIcon from "@mui/icons-material/ManageAccounts";
import EditIcon from "@mui/icons-material/Edit";
import PasswordIcon from "@mui/icons-material/Password";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import FormUser from "./FormUser";
import PrivacySetting from "./PrivateSetting";
import ChangePassword from "./ChangePassword";
import { Link } from "react-router-dom";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import axios from "axios";
const User = ({ onLogout, userData }) => {
  let [click, setClick] = useState(false);
  const [changepass, setChangepass] = useState(false);
  const [settingPrivacy, setSetting] = useState(false);
  const [mycv, setMycv] = useState(true);
  const [file, setFile] = useState();
  const [photo, setPhoto] = useState();
  const [data, getFile] = useState({ name: "", path: "" });
  const [progress, setProgess] = useState(0); // progess bar
  console.log("--------", userData);
  function handleChange(e) {
    console.log("e.target.files[0]", e.target.files[0]);
    setProgess(0);
    const file = e.target.files[0];
    setFile(file);
    setPhoto(URL.createObjectURL(e.target.files[0]));
  }
  const uploadFile = () => {
    const formData = new FormData();
    formData.append("file", file); // appending file

    console.log("formData: ", formData);
    axios
      .put(
        `http://localhost:8000/api/users/${localStorage.getItem(
          "userId"
        )}/photo`,
        formData,
        {
          onUploadProgress: (ProgressEvent) => {
            let progress =
              Math.round((ProgressEvent.loaded / ProgressEvent.total) * 100) +
              "%";
            setProgess(progress);
          },
          headers: {
            authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        }
      )
      .then((result) => {
        console.log(result);
        getFile({
          name: result.data.name,
          path: `http://localhost:8000/public/uploads` + result.data.path,
        });
        alert("Зураг амжилттай орууллаа...");
        console.log("------->", result.data);
      })
      .catch((err) => {
        alert("Error!!!");
        console.log(err);
      });
  };
  const changePassButton = () => {
    setMycv(false);
    setSetting(false);
    setChangepass(true);
    setClick(!click);
  };
  const settingPrivacyButton = () => {
    setMycv(false);
    setSetting(true);
    setChangepass(false);
    setClick(!click);
  };
  const myCVButton = () => {
    setMycv(true);
    setSetting(false);
    setChangepass(false);
    setClick(!click);
  };
  const handleClick = () => {
    setClick(!click);
    // setMycv(false);
    // setSetting(false);
    // setChangepass(false);
  };
  const switchFunc = () => {
    if (mycv === true) return <FormUser userData={userData} photo={file} />;
    else if (settingPrivacy === true) return <PrivacySetting photo={photo} />;
    else if (changepass === true) return <ChangePassword />;
  };
  return (
    <div className="flex w-full h-full">
      <div className="w-full md:px-6  h-full sm:flex mt-16 md:mt-18">
        {!click ? (
          <div className="p-2">
            <button onClick={handleClick} className=" sm:hidden">
              {" "}
              <ArrowForwardIosIcon />{" "}
            </button>
          </div>
        ) : (
          <div className="p-2">
            <button onClick={handleClick} className=" sm:hidden">
              {" "}
              <ArrowBackIosIcon />{" "}
            </button>
          </div>
        )}
        {click ? (
          <div className=" h-full sm:hidden  sm:border-r sm:border-amber-400 p-3  space-y-4">
            <div className="w-full m-auto">
              <div className="flex  justify-center">
                <Badge
                  overlap="circular"
                  anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
                  badgeContent={
                    <IconButton
                      color="secondary"
                      aria-label="upload picture"
                      component="label"
                    >
                      <input
                        hidden
                        name="photo"
                        accept="image/*"
                        type="file"
                        onChange={(e) => handleChange(e)}
                      />
                      <EditIcon />
                    </IconButton>
                  }
                >
                  <Avatar
                    alt="Profile"
                    sx={{ width: 80, height: 80 }}
                    src={photo}
                  />
                </Badge>
              </div>
              <div className="flex justify-center">
                {localStorage.getItem("username")}
              </div>
            </div>

            <div className="md:px-8 space-y-6">
              <div className=" rounded-md w-52 py-2 px-3 hover:bg-amber-200 ">
                <button
                  onClick={myCVButton}
                  className="w-full flex items-center space-x-2 "
                >
                  <TextSnippetIcon /> <p>Миний анкет</p>
                </button>
              </div>
              <div className=" rounded-md w-52 py-2 px-3 hover:bg-amber-200 ">
                <button
                  onClick={settingPrivacyButton}
                  className="w-full flex items-center space-x-2 "
                >
                  <ManageAccountsIcon /> <p>Хувийн тохиргоо</p>
                </button>
              </div>
              <div className=" rounded-md w-52 py-2 px-3 hover:bg-amber-200 ">
                <button
                  onClick={changePassButton}
                  className="w-full flex items-center space-x-2 "
                >
                  <PasswordIcon /> <p>Нууц үг солих</p>
                </button>
              </div>
              <div className=" rounded-md w-52 py-2 px-3 hover:bg-amber-200 ">
                <Link to="/">
                  <button
                    onClick={onLogout}
                    className="w-full w-full flex items-center space-x-2 "
                  >
                    <LogoutIcon /> <p>Гарах</p>
                  </button>
                </Link>
              </div>
            </div>
          </div>
        ) : null}
        <div className="w-1/4 h-full hidden sm:inline  sm:border-r sm:border-amber-400    md:pt-10 space-y-4">
          <div className="flex justify-center">
            <Badge
              overlap="circular"
              anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
              badgeContent={
                <IconButton
                  color="secondary"
                  aria-label="upload picture"
                  component="label"
                >
                  <input
                    hidden
                    accept="image/*"
                    type="file"
                    // ref={el}
                    onChange={(e) => handleChange(e)}
                  />
                  <EditIcon />
                </IconButton>
              }
            >
              <Avatar
                alt="Profile"
                sx={{ width: 80, height: 80 }}
                src={photo}
              />
            </Badge>
          </div>
          {/* {progress} */}
          {/* <button onClick={uploadFile}>Upload</button> */}
          {data.path && <img src={data.path} alt={data.name} />}
          <div className="flex justify-center">
            {localStorage.getItem("username")}
          </div>

          <div className="md:px-8 space-y-6">
            <div className=" rounded-md w-52 py-2 px-3 hover:bg-amber-200 ">
              <button
                onClick={myCVButton}
                className="w-full flex items-center space-x-2 "
              >
                <TextSnippetIcon /> <p>Миний анкет</p>
              </button>
            </div>
            <div className=" rounded-md w-52 py-2 px-3 hover:bg-amber-200 ">
              <button
                onClick={settingPrivacyButton}
                className="w-full flex items-center space-x-2 "
              >
                <ManageAccountsIcon /> <p>Хувийн тохиргоо</p>
              </button>
            </div>
            <div className=" rounded-md w-52 py-2 px-3 hover:bg-amber-200 ">
              <button
                onClick={changePassButton}
                className="w-full flex items-center space-x-2 "
              >
                <PasswordIcon /> <p>Нууц үг солих</p>
              </button>
            </div>
            <div className=" rounded-md w-52 py-2 px-3 hover:bg-amber-200 ">
              <Link to="/">
                <button
                  onClick={onLogout}
                  className="w-full w-full flex items-center space-x-2 "
                >
                  <LogoutIcon /> <p>Гарах</p>
                </button>
              </Link>
            </div>
          </div>
        </div>
        <div className="sm:hidden">{!click && switchFunc()}</div>
        <div className="hidden sm:inline w-full">{switchFunc()}</div>
      </div>
    </div>
  );
};
export default User;
