import React, { useState } from "react";
import LineB from "../container/lineB/LineB";
import { Avatar, Badge, IconButton, Input } from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import axios from "axios";
const PrivateSetting = (props) => {
  let nameL = localStorage.getItem("username");
  let emailL = localStorage.getItem("email");
  let [name, setName] = useState(nameL);
  let [email, setEmail] = useState(emailL);
  let [error, setError] = useState(null);
  let [photo, setPhoto] = useState(props.photo);
  // const handleChangeData = (e) => {
  //   const { name, value } = e.target;
  //   const changeval = [...data];
  //   changeval[name] = value;
  // };
  function handleChange(e) {
    console.log(e.target.files);

    setPhoto(URL.createObjectURL(e.target.files[0]));
    // axios
    //   .put(
    //     `http://localhost:8000/api/resumes/${localStorage.getItem(
    //       "userId"
    //     )}/upload-photo`,
    //     {
    //       file: photo,
    //     },
    //     {
    //       headers: {
    //         authorization: `Bearer ${localStorage.getItem("token")}`,
    //         "Content-Type": "application/json",
    //       },
    //     }
    //   )
    //   .then((result) => {
    //     alert("Амжилттай зураг орууллаа...");
    //   })
    //   .catch((err) => setError(err.response));
  }
  const handleDataSave = () => {
    axios
      .put(
        `http://localhost:8000/api/users/${localStorage.getItem("userId")}`,
        {
          name,
          email,
        },
        {
          headers: {
            authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        }
      )
      .then((result) => {
        alert("Amjilttai uurchlugdluu...");
        localStorage.setItem("username", name);
        localStorage.setItem("email", email);
      })
      .catch((err) => setError(err.response));
  };
  return (
    <div className=" h-full  md:w-4/5 space-y-4 p-3 md:p-10 text-sx text-xs">
      <div className="text-xl font-bold ">Хувийн тохиргоо</div>
      <LineB></LineB>
      <div className="space-y-3 rounded-md border p-6 bg-slate-100">
        <div className="space-y-3">
          <div className="flex justify-center">
            <Badge
              overlap="circular"
              anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
              badgeContent={
                <IconButton
                  color="secondary"
                  aria-label="upload picture"
                  component="label"
                >
                  <input
                    onChange={(e) => handleChange(e)}
                    hidden
                    accept="image/*"
                    type="file"
                  />
                  <EditIcon />
                </IconButton>
              }
            >
              <Avatar
                alt="Travis Howard"
                sx={{ width: 80, height: 80 }}
                src={photo}
              />
            </Badge>
            {/* <Avatar sx={{ width: 80, height: 80 }}></Avatar> */}
          </div>
          <div className="space-y-2 grid grid-cols-1 md:grid-cols-2">
            <div>
              <p>Нэр:</p>
              <Input
                name="name"
                onChange={(e) => {
                  setName(e.target.value);
                }}
                placeholder="нэр"
                value={name}
              ></Input>
            </div>
            <div>
              <p>Имэйл:</p>
              <Input
                name="email"
                placeholder="имэйл"
                onChange={(e) => {
                  setEmail(e.target.value);
                }}
                value={email}
              ></Input>
            </div>
          </div>
        </div>
        <div className="flex pt-3">
          <button
            onClick={handleDataSave}
            className="border border-lime-400  rounded-md w-52 py-2 px-3 hover:bg-lime-400"
          >
            Хадгалах
          </button>
        </div>
      </div>
    </div>
  );
};
export default PrivateSetting;
