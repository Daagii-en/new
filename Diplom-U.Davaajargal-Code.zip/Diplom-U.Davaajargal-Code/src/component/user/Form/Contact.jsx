import React, { useState } from "react";
import { Input, TextField } from "@mui/material";
import axios from "axios";
export default function Contact() {
  let [contact, setContact] = useState({});
  let [error, setError] = useState(null);
  let handleDataSave = () => {
    console.log("...", contact);
    axios
      .put(
        `http://localhost:8000/api/resumes/${localStorage.getItem(
          "userId"
        )}/data`,
        {
          contact,
        },
        {
          headers: {
            authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        }
      )
      .then((result) => setContact(result.data.data))
      .catch((err) => setError(err.response));
  };
  return (
    <div className="space-y-3 rounded-md border p-6 bg-slate-100">
      <p className="text-base font-semibold">
        Холбоо барих мэдээлэл <span className="text-red-600">*</span>
      </p>
      <div className="space-y-3">
        <div className=" space-y-2 grid grid-cols-1 md:grid-cols-2">
          <div>
            <p>Утасны дугаар:</p>
            <Input
              placeholder="утасны дугаар"
              onChange={(e) => {
                setContact({ ...contact, phone: e.target.value });
              }}
              // value={contact.phone}
            ></Input>
          </div>
          <div>
            <p>Цахим хаяг:</p>
            <Input
              placeholder="цахим хаяг"
              onChange={(e) => {
                setContact({ ...contact, email: e.target.value });
              }}
              // value={contact.email}
            ></Input>
          </div>
          <div>
            <p>Гэрийн хаяг:</p>
            <Input
              placeholder="гэрийн хаяг"
              onChange={(e) => {
                setContact({ ...contact, address: e.target.value });
              }}
              // value={contact.address}
            ></Input>
          </div>
        </div>
        <div className="flex space-x-5 pt-3">
          <button
            onClick={handleDataSave}
            className="border border-lime-400  rounded-md w-52 py-2 px-3 hover:bg-lime-400"
          >
            Хадгалах
          </button>
        </div>
      </div>
    </div>
  );
}
