import React, { useState } from "react";
import { Input } from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import AddCircleOutlineRoundedIcon from "@mui/icons-material/AddCircleOutlineRounded";
import axios from "axios";

export default function Family() {
  let [family, setFamily] = useState([
    { name: null, who: null, age: null, positionF: null, phone: null },
  ]);
  let [error, setError] = useState(null);

  const addObject = (e) => {
    setFamily([
      ...family,
      { name: null, who: null, age: null, positionF: null, phone: null },
    ]);
  };
  const handleDelete = (i) => {
    const deleteVal = [...family];
    deleteVal.splice(i, 1);
    setFamily(deleteVal);
  };
  const handleChange = (e, i) => {
    const { name, value } = e.target;

    const changeVal = [...family];
    changeVal[i][name] = value;
    setFamily(changeVal);
  };
  let handleDataSave = () => {
    console.log("...", family);
    axios
      .put(
        `http://localhost:8000/api/resumes/${localStorage.getItem(
          "userId"
        )}/data`,
        {
          family,
        },
        {
          headers: {
            authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        }
      )
      .then((result) => alert("amjilttai hadgalagdlaa.."))
      .catch((err) => setError(err.response));
  };
  return (
    <div className="space-y-3 rounded-md border p-6 bg-slate-100">
      <p className="text-base font-semibold">Гэр бүлийн мэдээлэл </p>
      <div className="space-y-3">
        {family.map((e, i) => {
          return (
            <div className="md:flex md:justify-between rounded-md bg-slate-200 border p-6">
              <div
                key={i}
                className="space-y-2 md:space-y-0 md:space-x-2 grid grid-cols-1 md:grid-cols-2"
              >
                <div>
                  <p>Нэр:</p>
                  <Input
                    key={i}
                    name="name"
                    onChange={(e) => handleChange(e, i)}
                    placeholder="нэр"
                    value={e.name}
                  ></Input>
                </div>
                <div>
                  <p>Таны хэн болох:</p>
                  <Input
                    key={i}
                    name="who"
                    onChange={(e) => handleChange(e, i)}
                    placeholder="таны хэн болох"
                    value={e.who}
                  ></Input>
                </div>
                <div>
                  <p>Нас:</p>
                  <Input
                    key={i}
                    name="age"
                    onChange={(e) => handleChange(e, i)}
                    placeholder="нас"
                    value={e.age}
                  ></Input>
                </div>
                <div>
                  <p>Холбоо барих дугаар:</p>
                  <Input
                    key={i}
                    name="phone"
                    onChange={(e) => handleChange(e, i)}
                    placeholder="утасны дугаар"
                    value={e.phone}
                  ></Input>
                </div>
                <div>
                  <p>Ажил/албан тушаал:</p>
                  <Input
                    key={i}
                    name="positionF"
                    onChange={(e) => handleChange(e, i)}
                    placeholder="ажил албан тушаал"
                    value={e.positionF}
                  ></Input>
                </div>
              </div>
              <button
                className="bg-inherit  rounded p-2 hover:bg-red-300"
                onClick={() => handleDelete(i)}
              >
                <DeleteIcon />
              </button>
            </div>
          );
        })}
        <button
          className="bg-inherit rounded mt-2 p-2 hover:bg-lime-500"
          onClick={addObject}
        >
          Нэмэх <AddCircleOutlineRoundedIcon />
        </button>
        <div className="flex space-x-5 pt-3">
          <button
            onClick={handleDataSave}
            className="border border-lime-400  rounded-md w-52 py-2 px-3 hover:bg-lime-400"
          >
            Хадгалах
          </button>
        </div>
      </div>
    </div>
  );
}
