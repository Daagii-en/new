import React, { useState } from "react";
import { Input } from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import AddCircleOutlineRoundedIcon from "@mui/icons-material/AddCircleOutlineRounded";
import axios from "axios";

export default function Language() {
  let [language, setLanguage] = useState([{ name: null, level: null }]);
  let [error, setError] = useState(null);

  const addObject = (e) => {
    setLanguage([...language, { name: null, level: null }]);
  };
  const handleDelete = (i) => {
    const deleteVal = [...language];
    deleteVal.splice(i, 1);
    setLanguage(deleteVal);
  };
  const handleChange = (e, i) => {
    const { name, value } = e.target;

    const changeVal = [...language];
    changeVal[i][name] = value;
    setLanguage(changeVal);
  };
  let handleDataSave = () => {
    console.log("...", language);
    axios
      .put(
        `http://localhost:8000/api/resumes/${localStorage.getItem(
          "userId"
        )}/data`,
        {
          language,
        },
        {
          headers: {
            authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        }
      )
      .then((result) => alert("amjilttai hadgalagdlaa.."))
      .catch((err) => setError(err.response));
  };
  return (
    <div className="space-y-3 rounded-md border p-6 bg-slate-100">
      <p className="text-base font-semibold">Гадаа хэлний мэдээлэл</p>
      <div className="space-y-3">
        {language.map((e, i) => {
          return (
            <div className="md:flex md:justify-between rounded-md bg-slate-200 border p-6">
              <div
                key={i}
                className="space-y-2 md:space-y-0 md:space-x-2 grid grid-cols-1 md:grid-cols-2"
              >
                <div>
                  <p>Хэл:</p>
                  <Input
                    key={i}
                    name="name"
                    onChange={(e) => handleChange(e, i)}
                    placeholder="хэл"
                    value={e.name}
                  ></Input>
                </div>
                <div>
                  <p>Түвшин:</p>
                  <Input
                    key={i}
                    name="level"
                    onChange={(e) => handleChange(e, i)}
                    placeholder="түвшин"
                    value={e.level}
                  ></Input>
                </div>
              </div>
              <button
                className="bg-inherit  rounded p-2 hover:bg-red-300"
                onClick={() => handleDelete(i)}
              >
                <DeleteIcon />
              </button>
            </div>
          );
        })}
        <button
          className="bg-inherit rounded mt-2 p-2 hover:bg-lime-500"
          onClick={addObject}
        >
          Нэмэх <AddCircleOutlineRoundedIcon />
        </button>
        <div className="flex space-x-5 pt-3">
          <button
            onClick={handleDataSave}
            className="border border-lime-400  rounded-md w-52 py-2 px-3 hover:bg-lime-400"
          >
            Хадгалах
          </button>
        </div>
      </div>
    </div>
  );
}
