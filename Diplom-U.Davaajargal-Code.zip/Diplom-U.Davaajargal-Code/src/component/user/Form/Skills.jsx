import React, { useState } from "react";
import { Input, TextField } from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import AddCircleOutlineRoundedIcon from "@mui/icons-material/AddCircleOutlineRounded";
import axios from "axios";

export default function Skills() {
  let [skills, setSkills] = useState([{ name: null, level: null }]);
  let [error, setError] = useState(null);

  const addSkill = (e) => {
    setSkills([...skills, { name: null, level: null }]);
  };
  const handleDelete = (i) => {
    const deleteVal = [...skills];
    deleteVal.splice(i, 1);
    setSkills(deleteVal);
  };
  const handleChange = (e, i) => {
    const { name, value } = e.target;

    const changeSkill = [...skills];
    changeSkill[i][name] = value;
    setSkills(changeSkill);
  };
  let handleDataSave = () => {
    console.log("...", skills);
    axios
      .put(
        `http://localhost:8000/api/resumes/${localStorage.getItem(
          "userId"
        )}/data`,
        {
          skills,
        },
        {
          headers: {
            authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        }
      )
      .then((result) => alert("amjilttai hadgalagdlaa.."))
      .catch((err) => setError(err.response));
  };
  return (
    <div className="space-y-3 rounded-md border p-6 bg-slate-100">
      <p className="text-base font-semibold">Ур чадварын мэдээлэл</p>
      <div className="space-y-3">
        {skills.map((e, i) => {
          return (
            <div className="md:flex md:justify-between rounded-md bg-slate-200 border p-6">
              <div
                key={i}
                className="space-y-2 md:space-y-0 md:space-x-2 grid grid-cols-1 md:grid-cols-2"
              >
                <div>
                  <p>Төрөл:</p>
                  <Input
                    key={i}
                    name="name"
                    onChange={(e) => handleChange(e, i)}
                    placeholder="төрөл"
                    value={e.name}
                  ></Input>
                </div>
                <div>
                  <p>Түвшин:</p>
                  <Input
                    key={i}
                    name="level"
                    onChange={(e) => handleChange(e, i)}
                    placeholder="түвшин"
                    value={e.level}
                  ></Input>
                </div>
              </div>
              <button
                className="bg-inherit  rounded p-2 hover:bg-red-300"
                onClick={() => handleDelete(i)}
              >
                <DeleteIcon />
              </button>
            </div>
          );
        })}
        <button
          className="bg-inherit rounded mt-2 p-2 hover:bg-lime-500"
          onClick={addSkill}
        >
          Ур чадвар нэмэх <AddCircleOutlineRoundedIcon />
        </button>

        <div className="flex space-x-5 pt-3">
          <button
            onClick={handleDataSave}
            className="border border-lime-400  rounded-md w-52 py-2 px-3 hover:bg-lime-400"
          >
            Хадгалах
          </button>
        </div>
      </div>
    </div>
  );
}
