import React, { useState } from "react";
import { Input } from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import AddCircleOutlineRoundedIcon from "@mui/icons-material/AddCircleOutlineRounded";
import axios from "axios";

export default function Education() {
  let [education, setEducation] = useState([
    {
      institution: null,
      schoolName: null,
      degree: null,
      gpa: null,
      startDate: null,
      endDate: null,
      location: null,
      profession: null,
    },
  ]);
  let [error, setError] = useState(null);

  const addObject = (e) => {
    setEducation([
      ...education,
      {
        institution: null,
        schoolName: null,
        degree: null,
        rate: null,
        startDate: null,
        endDate: null,
        location: null,
        profession: null,
      },
    ]);
  };
  const handleDelete = (i) => {
    const deleteVal = [...education];
    deleteVal.splice(i, 1);
    setEducation(deleteVal);
  };
  const handleChange = (e, i) => {
    const { name, value } = e.target;

    const changeVal = [...education];
    changeVal[i][name] = value;
    setEducation(changeVal);
  };
  let handleDataSave = () => {
    console.log("...", education);
    axios
      .put(
        `http://localhost:8000/api/resumes/${localStorage.getItem(
          "userId"
        )}/data`,
        {
          education,
        },
        {
          headers: {
            authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        }
      )
      .then((result) => alert("amjilttai hadgalagdlaa.."))
      .catch((err) => setError(err.response));
  };
  return (
    <div className="space-y-3 rounded-md border p-6 bg-slate-100">
      <p className="text-base font-semibold">
        Боловсрол <span className="text-red-600">*</span>
      </p>
      <div className="space-y-3">
        {education.map((e, i) => {
          return (
            <div className="md:flex md:justify-between rounded-md bg-slate-200 border p-6">
              <div
                key={i}
                className="space-y-2 md:space-y-0 md:space-x-2 grid grid-cols-1 md:grid-cols-2"
              >
                <div>
                  <p>Байгууллага:</p>
                  <Input
                    key={i}
                    name="institution"
                    onChange={(e) => handleChange(e, i)}
                    placeholder="байгууллага"
                    value={e.institution}
                  ></Input>
                </div>
                <div>
                  <p>Сургууль:</p>
                  <Input
                    key={i}
                    name="schoolName"
                    onChange={(e) => handleChange(e, i)}
                    placeholder="сургууль"
                    value={e.schoolName}
                  ></Input>
                </div>
                <div>
                  <p>Мэргэжил:</p>
                  <Input
                    placeholder="мэргэжил"
                    key={i}
                    name="profession"
                    onChange={(e) => handleChange(e, i)}
                    value={e.profession}
                  ></Input>
                </div>
                <div>
                  <p>Боловсролын зэрэг:</p>
                  <Input
                    placeholder="зэрэг"
                    key={i}
                    name="degree"
                    onChange={(e) => handleChange(e, i)}
                    value={e.degree}
                  ></Input>
                </div>
                <div>
                  <p>Голч дүн:</p>
                  <Input
                    placeholder="голч"
                    key={i}
                    name="gpa"
                    onChange={(e) => handleChange(e, i)}
                    value={e.gpa}
                  ></Input>
                </div>
                <div>
                  <p>Элссэн он:</p>
                  <Input
                    placeholder="огноо"
                    key={i}
                    name="startDate"
                    onChange={(e) => handleChange(e, i)}
                    value={e.startDate}
                  ></Input>
                </div>
                <div>
                  <p>Төгссөн он:</p>
                  <Input
                    placeholder="огноо"
                    key={i}
                    name="endDate"
                    onChange={(e) => handleChange(e, i)}
                    value={e.endDate}
                  ></Input>
                </div>
                <div>
                  <p>Байршил:</p>
                  <Input
                    placeholder="хаана"
                    key={i}
                    name="location"
                    onChange={(e) => handleChange(e, i)}
                    value={e.location}
                  ></Input>
                </div>
              </div>
              <button
                className="bg-inherit  rounded p-2 hover:bg-red-300"
                onClick={() => handleDelete(i)}
              >
                <DeleteIcon />
              </button>
            </div>
          );
        })}
        <button
          className="bg-inherit rounded mt-2 p-2 hover:bg-lime-500"
          onClick={addObject}
        >
          Нэмэх <AddCircleOutlineRoundedIcon />
        </button>
        <div className="flex space-x-5 pt-3">
          <button
            onClick={handleDataSave}
            className="border border-lime-400  rounded-md w-52 py-2 px-3 hover:bg-lime-400"
          >
            Хадгалах
          </button>
        </div>
      </div>
    </div>
  );
}
