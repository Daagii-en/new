import React, { useState } from "react";
import { Input } from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import AddCircleOutlineRoundedIcon from "@mui/icons-material/AddCircleOutlineRounded";
import axios from "axios";

export default function Experiences() {
  let [experiences, setExperiences] = useState([
    {
      position: null,
      company: null,
      location: null,
      startDate: null,
      endDate: null,
    },
  ]);
  let [error, setError] = useState(null);

  const addObject = (e) => {
    setExperiences([
      ...experiences,
      {
        position: null,
        company: null,
        location: null,
        startDate: null,
        endDate: null,
      },
    ]);
  };
  const handleDelete = (i) => {
    const deleteVal = [...experiences];
    deleteVal.splice(i, 1);
    setExperiences(deleteVal);
  };
  const handleChange = (e, i) => {
    const { name, value } = e.target;

    const changeVal = [...experiences];
    changeVal[i][name] = value;
    setExperiences(changeVal);
  };
  let handleDataSave = () => {
    console.log("...", experiences);
    axios
      .put(
        `http://localhost:8000/api/resumes/${localStorage.getItem(
          "userId"
        )}/data`,
        {
          experiences,
        },
        {
          headers: {
            authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        }
      )
      .then((result) => alert("amjilttai hadgalagdlaa.."))
      .catch((err) => setError(err.response));
  };
  return (
    <div className="space-y-3 rounded-md border p-6 bg-slate-100">
      <p className="text-base font-semibold">Ажлын туршлага </p>
      <div className="space-y-3">
        {experiences.map((e, i) => {
          return (
            <div className="md:flex md:justify-between rounded-md bg-slate-200 border p-6">
              <div
                key={i}
                className="space-y-3 md:space-y-0 md:space-x-5 grid grid-cols-1 md:grid-cols-2"
              >
                <div>
                  <p>Байгууллагын нэр:</p>
                  <Input
                    key={i}
                    name="company"
                    onChange={(e) => handleChange(e, i)}
                    placeholder="байгууллагын нэр"
                    value={e.company}
                  ></Input>
                </div>
                <div>
                  <p>Албан тушаал, Мэргэжил:</p>
                  <Input
                    key={i}
                    name="position"
                    onChange={(e) => handleChange(e, i)}
                    placeholder="албан тушаал, мэргэжил"
                    value={e.position}
                  ></Input>
                </div>
                <div>
                  <p>Ажилд орсон огноо:</p>
                  <Input
                    key={i}
                    name="startDate"
                    onChange={(e) => handleChange(e, i)}
                    placeholder="огноо"
                    value={e.startDate}
                  ></Input>
                </div>
                <div>
                  <p>Ажлаас гарсан огноо:</p>
                  <Input
                    key={i}
                    name="endDate"
                    onChange={(e) => handleChange(e, i)}
                    placeholder="огноо"
                    value={e.endDate}
                  ></Input>
                </div>
                <div>
                  <p>Байршил:</p>
                  <Input
                    key={i}
                    name="location"
                    onChange={(e) => handleChange(e, i)}
                    placeholder="хаана?"
                    value={e.location}
                  ></Input>
                </div>
              </div>
              <button
                className="bg-inherit  rounded p-2 hover:bg-red-300"
                onClick={() => handleDelete(i)}
              >
                <DeleteIcon />
              </button>
            </div>
          );
        })}
        <button
          className="bg-inherit rounded mt-2 p-2 hover:bg-lime-500"
          onClick={addObject}
        >
          Нэмэх <AddCircleOutlineRoundedIcon />
        </button>
        <div className="flex space-x-5 pt-3">
          <button
            onClick={handleDataSave}
            className="border border-lime-400  rounded-md w-52 py-2 px-3 hover:bg-lime-400"
          >
            Хадгалах
          </button>
        </div>
      </div>
    </div>
  );
}
