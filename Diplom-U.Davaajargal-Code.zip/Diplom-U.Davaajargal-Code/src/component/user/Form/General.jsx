import React, { useState } from "react";
import { IconButton, Input, TextField } from "@mui/material";
// import FileUploadIcon from "@mui/icons-material/FileUpload";
import axios from "axios";
export default function General() {
  let [general, setGeneral] = useState(null);
  let [error, setError] = useState(null);
  let handleDataSave = () => {
    console.log("...", general);
    axios
      .put(
        `http://localhost:8000/api/resumes/${localStorage.getItem(
          "userId"
        )}/data`,
        {
          general,
        },
        {
          headers: {
            authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        }
      )
      .then((result) => {
        setGeneral(result.data.data);
        alert("Амжилттай хадгалагдлаа.");
      })
      .catch((err) => setError(err.response));
  };
  return (
    <div className="space-y-3 rounded-md border p-6 bg-slate-100">
      <p className="text-base font-semibold">
        Ерөнхий мэдээлэл <span className="text-red-600">*</span>
      </p>
      <div className="space-y-3">
        <div>
          <p>Миний тухай:</p>
          <TextField
            id="outlined-basic"
            label=""
            name="summary"
            onChange={(e) => {
              setGeneral({ ...general, summary: e.target.value });
            }}
            className="w-full"
            variant="outlined"
            // value={general.summary}
          ></TextField>
        </div>
        <div className="space-y-2 grid grid-cols-1 md:grid-cols-2">
          <div>
            <p>Эцэг/эхийн нэр:</p>
            <Input
              placeholder="эцэг/эхийн нэр"
              // value={general.lastname}
              onChange={(e) => {
                setGeneral({ ...general, lastname: e.target.value });
              }}
            />
          </div>
          <div>
            <p>Өөрийн нэр:</p>
            <Input
              placeholder="өөрийн нэр"
              onChange={(e) => {
                setGeneral({ ...general, firstname: e.target.value });
              }}
              // value={general.firstname}
            ></Input>
          </div>
          <div>
            <p>Регистрийн дугаар:</p>
            <Input
              placeholder="регистрийн дугаар"
              onChange={(e) => {
                setGeneral({ ...general, register: e.target.value });
              }}
              // value={general.register}
            ></Input>
          </div>
          <div>
            <p>Хүйс:</p>
            <Input
              placeholder="хүйс"
              onChange={(e) => {
                setGeneral({ ...general, gender: e.target.value });
              }}
              // value={general.gender}
            ></Input>
          </div>
          <div>
            <p>Төрсөн огноо:</p>
            <Input
              placeholder="төрсөн он сар өдөр"
              onChange={(e) => {
                setGeneral({ ...general, birthdate: e.target.value });
              }}
              // value={general.birthdate}
            ></Input>
          </div>
          <div>
            <p>Нас:</p>
            <Input
              placeholder="нас"
              onChange={(e) => {
                setGeneral({ ...general, age: e.target.value });
              }}
              // value={general.age}
            ></Input>
          </div>
        </div>
        <div className="flex space-x-5 pt-3">
          <button
            onClick={handleDataSave}
            className="border border-lime-400  rounded-md w-52 py-2 px-3 hover:bg-lime-400"
          >
            Хадгалах
          </button>
        </div>
      </div>
    </div>
  );
}
