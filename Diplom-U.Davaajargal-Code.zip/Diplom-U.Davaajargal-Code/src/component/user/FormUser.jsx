import React, { useEffect, useState } from "react";
import LineB from "../container/lineB/LineB";
import { IconButton, Input, TextField } from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import AddCircleOutlineRoundedIcon from "@mui/icons-material/AddCircleOutlineRounded";
import FileUploadIcon from "@mui/icons-material/FileUpload";
import axios from "axios";

// import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
// import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
// import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import Alert from "@mui/material/Alert";
import Stack from "@mui/material/Stack";

const FormUser = (props) => {
  let [userData, setUserData] = useState(props.userData);
  // console.log("userdata: ", props.userData);
  let [careers, setCareers] = useState([{}]);
  let [photo, setPhoto] = useState(props.photo);
  // let [cv, setCV] = useState(null);
  let [general, setGeneral] = useState({
    summary: null,
    lastname: null,
    firstname: null,
    birthdate: null,
    age: null,
    gender: null,
    register: null,
  });
  const [cv, setFile] = useState(null);
  //-----------------
  let [error, setError] = useState(null);
  let [contact, setContact] = useState({
    phone: null,
    email: null,
    address: null,
  });
  let [desiredjob, setDesiredjob] = useState({
    job: null,
    salary: null,
    worktime: null,
  });
  let [education, setEducation] = useState([
    {
      institution: null,
      schoolName: null,
      degree: null,
      gpa: null,
      startDate: null,
      endDate: null,
      location: null,
      profession: null,
    },
  ]);
  let [experiences, setExperiences] = useState([
    {
      position: null,
      company: null,
      location: null,
      startDate: null,
      endDate: null,
    },
  ]);
  let [family, setFamily] = useState([
    { name: null, who: null, age: null, positionF: null, phone: null },
  ]);
  let [language, setLanguage] = useState([{ name: null, level: null }]);
  let [skills, setSkills] = useState([{ name: null, level: null }]);
  //-------------------
  const addObjectEdu = (e) => {
    setEducation([
      ...education,
      {
        institution: null,
        schoolName: null,
        degree: null,
        rate: null,
        startDate: null,
        endDate: null,
        location: null,
        profession: null,
      },
    ]);
  };
  const handleDeleteEdu = (i) => {
    const deleteVal = [...education];
    deleteVal.splice(i, 1);
    setEducation(deleteVal);
  };
  const handleChangeEdu = (e, i) => {
    const { name, value } = e.target;

    const changeVal = [...education];
    changeVal[i][name] = value;
    setEducation(changeVal);
  };
  //----------------------------
  const addObjectExp = (e) => {
    setExperiences([
      ...experiences,
      {
        position: null,
        company: null,
        location: null,
        startDate: null,
        endDate: null,
      },
    ]);
  };
  const handleDeleteExp = (i) => {
    const deleteVal = [...experiences];
    deleteVal.splice(i, 1);
    setExperiences(deleteVal);
  };
  const handleChangeExp = (e, i) => {
    const { name, value } = e.target;

    const changeVal = [...experiences];
    changeVal[i][name] = value;
    setExperiences(changeVal);
  };
  //---------------------------------
  const addObjectFam = (e) => {
    setFamily([
      ...family,
      { name: null, who: null, age: null, positionF: null, phone: null },
    ]);
  };
  const handleDeleteFam = (i) => {
    const deleteVal = [...family];
    deleteVal.splice(i, 1);
    setFamily(deleteVal);
  };
  const handleChangeFam = (e, i) => {
    const { name, value } = e.target;

    const changeVal = [...family];
    changeVal[i][name] = value;
    setFamily(changeVal);
  };
  //-----------------------
  const addObjectLan = (e) => {
    setLanguage([...language, { name: null, level: null }]);
  };
  const handleDeleteLan = (i) => {
    const deleteVal = [...language];
    deleteVal.splice(i, 1);
    setLanguage(deleteVal);
  };
  const handleChangeLan = (e, i) => {
    const { name, value } = e.target;

    const changeVal = [...language];
    changeVal[i][name] = value;
    setLanguage(changeVal);
  };
  //-------------------------
  const addSkillSki = (e) => {
    setSkills([...skills, { name: null, level: null }]);
  };
  const handleDeleteSki = (i) => {
    const deleteVal = [...skills];
    deleteVal.splice(i, 1);
    setSkills(deleteVal);
  };
  const handleChangeSki = (e, i) => {
    const { name, value } = e.target;

    const changeSkill = [...skills];
    changeSkill[i][name] = value;
    setSkills(changeSkill);
  };
  //-----------------
  const handleFileUpload = (event) => {
    setFile(event.target.files[0]);
  };
  useEffect(() => {
    axios
      .get("http://localhost:8000/api/careers")
      .then((result) => {
        setCareers(result.data.data);
        // console.log("careers: ", careers);
      })
      .catch((err) => setError(err.response));
    // axios
    //   .get(
    //     `http://localhost:8000/api/resumes/${localStorage.getItem(
    //       "userId"
    //     )}/data`,
    //     {
    //       headers: {
    //         authorization: `Bearer ${localStorage.getItem("token")}`,
    //       },
    //     }
    //   )
    //   .then((result) => {
    //     setUserData(result.data.data);
    //     // setGeneral(result.data.data.general);
    //     // setContact(result.data.data.contact);
    //     // setDesiredjob(result.data.data.desiredjob);
    //     // setEducation(result.data.data.education);
    //     // setExperiences(result.data.data.experiences);
    //     // setFamily(result.data.data.family);
    //     // setLanguage(result.data.data.language);
    //     // setSkills(result.data.data.skills);
    //   })
    //   .catch((err) => setError(err.response));
  });
  let handleDataSave = () => {
    console.log("props.photo= ", props);
    axios
      .put(
        `http://localhost:8000/api/resumes/${localStorage.getItem(
          "userId"
        )}/data`,
        {
          general,
          contact,
          desiredjob,
          education,
          experiences,
          skills,
          language,
          family,
          photo,
          cv,
          updatedAt: Date.now(),
        },
        {
          headers: {
            authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        }
      )
      .then((result) => {
        setUserData(result.data.data);
        alert("Өөрчлөлт амжилттай...");
        <Stack sx={{ width: "100%" }} spacing={2}>
          <Alert severity="success">
            This is a success alert — check it out!
          </Alert>
        </Stack>;
        // console.log("------->", result.data.data);
      })
      .catch((err) => {
        setError(err.response);
        console.log("asdasd ", err.response);
        alert(
          "Алдаа: Анкетын мэдээлэл дутуу байна та бүх талбарыг бөглөнө үү."
        );
        <Stack sx={{ width: "100%" }} spacing={2}>
          <Alert severity="error">{error}</Alert>
        </Stack>;
      });
  };
  let handleDataCreate = () => {
    console.log("==> create resume");
    axios
      .post(
        `http://localhost:8000/api/resumes/${localStorage.getItem(
          "userId"
        )}/data`,
        {
          general,
          contact,
          desiredjob,
          education,
          experiences,
          skills,
          language,
          family,
          photo,
          cv,
        },
        {
          headers: {
            authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json",
          },
        }
      )
      .then((result) => {
        setUserData(result.data.data);
        alert("Анкет амжилттай үүсэглээ...");
        // console.log("------->", result.data.data);
      })
      .catch((err) => {
        setError(err.response);
        alert(
          "Алдаа: Анкетын мэдээлэл дутуу байна та бүх талбарыг бөглөнө үү."
        );
      });
  };
  // const data = userData;

  return (
    <div className=" h-fit sm:border-l sm:border-amber-400 w-full space-y-4 p-3  md:p-10 text-sx text-xs">
      <div className="text-xl font-bold ">Миний анкет</div>
      <LineB />
      <>
        <div className="space-y-3 rounded-md border p-6 bg-slate-100">
          <p className="text-base font-semibold">
            Ерөнхий мэдээлэл <span className="text-red-600">*</span>
          </p>
          <div className="space-y-3">
            <div>
              <p>Миний тухай:</p>
              <TextField
                id="outlined-basic"
                label=""
                name="summary"
                onChange={(e) => {
                  setGeneral({ ...general, summary: e.target.value });
                }}
                className="w-full"
                variant="outlined"
                value={general.summary}
              ></TextField>
            </div>
            <div className="space-y-2 grid grid-cols-1 md:grid-cols-2">
              <div>
                <p>Эцэг/эхийн нэр:</p>
                <Input
                  placeholder="эцэг/эхийн нэр"
                  value={general.lastname}
                  onChange={(e) => {
                    setGeneral({ ...general, lastname: e.target.value });
                  }}
                />
              </div>
              <div>
                <p>Өөрийн нэр:</p>
                <Input
                  placeholder="өөрийн нэр"
                  onChange={(e) => {
                    setGeneral({ ...general, firstname: e.target.value });
                  }}
                  value={general.firstname}
                ></Input>
              </div>
              <div>
                <p>Регистрийн дугаар:</p>
                <Input
                  placeholder="регистрийн дугаар"
                  onChange={(e) => {
                    setGeneral({ ...general, register: e.target.value });
                  }}
                  value={general.register}
                ></Input>
              </div>
              <div>
                <p>Хүйс:</p>
                <select
                  onChange={(e) =>
                    setGeneral({ ...general, gender: e.target.value })
                  }
                  className="p-2 w-1/2 rounded"
                >
                  <option value={null}>Сонгоно уу</option>
                  <option value={"Эмэгтэй"}>Эмэгтэй</option>
                  <option value={"Эрэгтэй"}>Эрэгтэй</option>
                </select>
              </div>
              <div>
                <p>Төрсөн огноо:</p>
                <input
                  onChange={(e) => {
                    setGeneral({ ...general, birthdate: e.target.value });
                  }}
                  value={general.birthdate}
                  type="date"
                  className="p-2 rounded w-1/2"
                />
              </div>
              <div>
                <p>Нас:</p>
                <Input
                  placeholder="нас"
                  onChange={(e) => {
                    setGeneral({ ...general, age: e.target.value });
                  }}
                  value={general.age}
                ></Input>
              </div>
            </div>
          </div>
        </div>
        <div className="space-y-3 rounded-md border p-6 bg-slate-100">
          <p className="text-base font-semibold">
            Холбоо барих мэдээлэл <span className="text-red-600">*</span>
          </p>
          <div className="space-y-3">
            <div className=" space-y-2 grid grid-cols-1 md:grid-cols-2">
              <div>
                <p>Утасны дугаар:</p>
                <Input
                  placeholder="утасны дугаар"
                  onChange={(e) => {
                    setContact({ ...contact, phone: e.target.value });
                  }}
                  value={contact.phone}
                ></Input>
              </div>
              <div>
                <p>Цахим хаяг:</p>
                <Input
                  placeholder="цахим хаяг"
                  onChange={(e) => {
                    setContact({ ...contact, email: e.target.value });
                  }}
                  value={contact.email}
                ></Input>
              </div>
              <div>
                <p>Гэрийн хаяг:</p>
                <Input
                  placeholder="гэрийн хаяг"
                  onChange={(e) => {
                    setContact({ ...contact, address: e.target.value });
                  }}
                  value={contact.address}
                ></Input>
              </div>
            </div>
          </div>
        </div>
        <div className="space-y-3 rounded-md border p-6 bg-slate-100">
          <p className="text-base font-semibold">
            Таны хүсэж буй ажил<span className="text-red-600">*</span>
          </p>
          <div className="space-y-3">
            <div className=" space-y-2 grid grid-cols-1 md:grid-cols-2">
              <div>
                <p>Ажил:</p>
                {/* {careers && careers.map((e, i) => <li key={i}>{e.name}</li>)} */}
                <select
                  onChange={(e) => {
                    setDesiredjob({ ...desiredjob, job: e.target.value });
                  }}
                  className="p-2 w-1/2 rounded"
                >
                  {/* <option value={null} disabled>
                    Сонгоно уу
                  </option> */}
                  <option value={null}>Сонгоно уу</option>
                  {careers &&
                    careers.map((e, i) => (
                      <option key={e.id} value={e.id}>
                        {e.name}
                      </option>
                    ))}
                </select>
                {/* <Input
                  placeholder="ажил"
                  onChange={(e) => {
                    setDesiredjob({ ...desiredjob, job: e.target.value });
                  }}
                  value={desiredjob.job}
                ></Input> */}
              </div>
              <div>
                <p>Цалин:</p>
                <Input
                  placeholder="цалин"
                  onChange={(e) => {
                    setDesiredjob({ ...desiredjob, salary: e.target.value });
                  }}
                  value={desiredjob.salary}
                ></Input>
              </div>
              <div>
                <p>Ажлын цаг:</p>
                <select
                  onChange={(e) =>
                    setDesiredjob({ ...desiredjob, worktime: e.target.value })
                  }
                  className="p-2 w-1/2 rounded"
                >
                  <option value={null}>Сонгоно уу</option>
                  <option value={"Бүтэн цаг"}>Бүтэн цаг</option>
                  <option value={"Хагас цаг"}>Хагас цаг</option>
                  <option value={"Дадлагажигч"}>Дадлагажигч</option>
                </select>
                {/* <Input
                  placeholder="ажлын цаг"
                  onChange={(e) => {
                    setDesiredjob({ ...desiredjob, worktime: e.target.value });
                  }}
                  value={desiredjob.worktime}
                ></Input> */}
              </div>
            </div>
          </div>
        </div>
        <div className="space-y-3 rounded-md border p-6 bg-slate-100">
          <p className="text-base font-semibold">
            Боловсрол <span className="text-red-600">*</span>
          </p>
          <div className="space-y-3">
            {education.map((e, i) => {
              return (
                <div className="md:flex md:justify-between rounded-md bg-slate-200 border p-6">
                  <div
                    key={i}
                    className="space-y-2 md:space-y-0 md:space-x-2 grid grid-cols-1 md:grid-cols-2"
                  >
                    <div>
                      <p>Байгууллага:</p>
                      <select
                        key={i}
                        name="institution"
                        onChange={(e) => handleChangeEdu(e, i)}
                        className="p-2 w-full rounded"
                      >
                        <option value={null}>Сонгоно уу</option>
                        <option value={"Ахлах сургууль"}>Ахлах сургууль</option>
                        <option value={"Их сургууль"}>Их сургууль</option>
                        <option value={"Коллеж"}>Коллеж</option>
                        <option value={"Сургалт"}>Сургалт</option>
                      </select>
                    </div>
                    <div>
                      <p>Сургууль:</p>
                      <Input
                        key={i}
                        name="schoolName"
                        onChange={(e) => handleChangeEdu(e, i)}
                        placeholder="сургууль"
                        value={e.schoolName}
                      ></Input>
                    </div>
                    <div>
                      <p>Мэргэжил:</p>
                      <Input
                        placeholder="мэргэжил"
                        key={i}
                        name="profession"
                        onChange={(e) => handleChangeEdu(e, i)}
                        value={e.profession}
                      ></Input>
                    </div>
                    <div>
                      <p>Боловсролын зэрэг:</p>
                      <select
                        key={i}
                        name="degree"
                        onChange={(e) => handleChangeEdu(e, i)}
                        className="p-2 w-full rounded"
                      >
                        <option value={null}>Сонгоно уу</option>
                        <option value={"Ахлах боловсрол"}>
                          Ахлах боловсрол
                        </option>
                        <option value={"Бага боловсрол"}>Бага боловсрол</option>
                        <option value={"Бакалавр "}>Бакалавр </option>
                        <option value={"Дунд боловсрол"}>Дунд боловсрол</option>
                        <option value={"Магистр"}>Магистр</option>
                        <option value={"Доктор"}>Доктор</option>
                        <option value={"Пропессор"}>Пропессор</option>
                        <option value={"Сертификат"}>Сертификат</option>
                      </select>
                    </div>
                    <div>
                      <p>Голч дүн:</p>
                      <Input
                        placeholder="голч"
                        key={i}
                        name="gpa"
                        onChange={(e) => handleChangeEdu(e, i)}
                        value={e.gpa}
                      ></Input>
                    </div>
                    <div>
                      <p>Элссэн он:</p>
                      <Input
                        placeholder="огноо"
                        key={i}
                        name="startDate"
                        onChange={(e) => handleChangeEdu(e, i)}
                        value={e.startDate}
                      ></Input>
                    </div>
                    <div>
                      <p>Төгссөн он:</p>
                      <Input
                        placeholder="огноо"
                        key={i}
                        name="endDate"
                        onChange={(e) => handleChangeEdu(e, i)}
                        value={e.endDate}
                      ></Input>
                    </div>
                    <div>
                      <p>Байршил:</p>
                      <Input
                        placeholder="хаана"
                        key={i}
                        name="location"
                        onChange={(e) => handleChangeEdu(e, i)}
                        value={e.location}
                      ></Input>
                    </div>
                  </div>
                  <button
                    className="bg-inherit  rounded p-2 hover:bg-red-300"
                    onClick={() => handleDeleteEdu(i)}
                  >
                    <DeleteIcon />
                  </button>
                </div>
              );
            })}
            <button
              className="bg-inherit rounded mt-2 p-2 hover:bg-lime-500"
              onClick={addObjectEdu}
            >
              Нэмэх <AddCircleOutlineRoundedIcon />
            </button>
          </div>
        </div>
        <div className="space-y-3 rounded-md border p-6 bg-slate-100">
          <p className="text-base font-semibold">Ажлын туршлага </p>
          <div className="space-y-3">
            {experiences.map((e, i) => {
              return (
                <div className="md:flex md:justify-between rounded-md bg-slate-200 border p-6">
                  <div
                    key={i}
                    className="space-y-3 md:space-y-0 md:space-x-5 grid grid-cols-1 md:grid-cols-2"
                  >
                    <div>
                      <p>Байгууллагын нэр:</p>
                      <Input
                        key={i}
                        name="company"
                        onChange={(e) => handleChangeExp(e, i)}
                        placeholder="байгууллагын нэр"
                        value={e.company}
                      ></Input>
                    </div>
                    <div>
                      <p>Албан тушаал, Мэргэжил:</p>
                      <Input
                        key={i}
                        name="position"
                        onChange={(e) => handleChangeExp(e, i)}
                        placeholder="албан тушаал, мэргэжил"
                        value={e.position}
                      ></Input>
                    </div>
                    <div>
                      <p>Ажилд орсон огноо:</p>
                      <Input
                        key={i}
                        name="startDate"
                        onChange={(e) => handleChangeExp(e, i)}
                        placeholder="огноо"
                        value={e.startDate}
                      ></Input>
                    </div>
                    <div>
                      <p>Ажлаас гарсан огноо:</p>
                      <Input
                        key={i}
                        name="endDate"
                        onChange={(e) => handleChangeExp(e, i)}
                        placeholder="огноо"
                        value={e.endDate}
                      ></Input>
                    </div>
                    <div>
                      <p>Байршил:</p>
                      <Input
                        key={i}
                        name="location"
                        onChange={(e) => handleChangeExp(e, i)}
                        placeholder="хаана?"
                        value={e.location}
                      ></Input>
                    </div>
                  </div>
                  <button
                    className="bg-inherit  rounded p-2 hover:bg-red-300"
                    onClick={() => handleDeleteExp(i)}
                  >
                    <DeleteIcon />
                  </button>
                </div>
              );
            })}
            <button
              className="bg-inherit rounded mt-2 p-2 hover:bg-lime-500"
              onClick={addObjectExp}
            >
              Нэмэх <AddCircleOutlineRoundedIcon />
            </button>
          </div>
        </div>
        <div className="space-y-3 rounded-md border p-6 bg-slate-100">
          <p className="text-base font-semibold">Гэр бүлийн мэдээлэл </p>
          <div className="space-y-3">
            {family.map((e, i) => {
              return (
                <div className="md:flex md:justify-between rounded-md bg-slate-200 border p-6">
                  <div
                    key={i}
                    className="space-y-2 md:space-y-0 md:space-x-2 grid grid-cols-1 md:grid-cols-2"
                  >
                    <div>
                      <p>Нэр:</p>
                      <Input
                        key={i}
                        name="name"
                        onChange={(e) => handleChangeFam(e, i)}
                        placeholder="нэр"
                        value={e.name}
                      ></Input>
                    </div>
                    <div>
                      <p>Таны хэн болох:</p>
                      <Input
                        key={i}
                        name="who"
                        onChange={(e) => handleChangeFam(e, i)}
                        placeholder="таны хэн болох"
                        value={e.who}
                      ></Input>
                    </div>
                    <div>
                      <p>Нас:</p>
                      <Input
                        key={i}
                        name="age"
                        onChange={(e) => handleChangeFam(e, i)}
                        placeholder="нас"
                        value={e.age}
                      ></Input>
                    </div>
                    <div>
                      <p>Холбоо барих дугаар:</p>
                      <Input
                        key={i}
                        name="phone"
                        onChange={(e) => handleChangeFam(e, i)}
                        placeholder="утасны дугаар"
                        value={e.phone}
                      ></Input>
                    </div>
                    <div>
                      <p>Ажил/албан тушаал:</p>
                      <Input
                        key={i}
                        name="positionF"
                        onChange={(e) => handleChangeFam(e, i)}
                        placeholder="ажил албан тушаал"
                        value={e.positionF}
                      ></Input>
                    </div>
                  </div>
                  <button
                    className="bg-inherit  rounded p-2 hover:bg-red-300"
                    onClick={() => handleDeleteFam(i)}
                  >
                    <DeleteIcon />
                  </button>
                </div>
              );
            })}
            <button
              className="bg-inherit rounded mt-2 p-2 hover:bg-lime-500"
              onClick={addObjectFam}
            >
              Нэмэх <AddCircleOutlineRoundedIcon />
            </button>
          </div>
        </div>
        <div className="space-y-3 rounded-md border p-6 bg-slate-100">
          <p className="text-base font-semibold">Гадаа хэлний мэдээлэл</p>
          <div className="space-y-3">
            {language.map((e, i) => {
              return (
                <div className="md:flex md:justify-between rounded-md bg-slate-200 border p-6">
                  <div
                    key={i}
                    className="space-y-2 md:space-y-0 md:space-x-2 grid grid-cols-1 md:grid-cols-2"
                  >
                    <div>
                      <p>Хэл:</p>
                      <Input
                        key={i}
                        name="name"
                        onChange={(e) => handleChangeLan(e, i)}
                        placeholder="хэл"
                        value={e.name}
                      ></Input>
                    </div>
                    <div>
                      <p>Түвшин:</p>
                      <select
                        key={i}
                        name="level"
                        onChange={(e) => handleChangeLan(e, i)}
                        className="p-2 w-full rounded"
                      >
                        <option value={null}>Сонгоно уу</option>
                        <option value={"Анхан"}>Анхан</option>
                        <option value={"Дунд"}>Дунд</option>
                        <option value={"Ахисан"}>Ахисан</option>
                      </select>
                      {/* <Input
                        key={i}
                        name="level"
                        onChange={(e) => handleChangeLan(e, i)}
                        placeholder="түвшин"
                        value={e.level}
                      ></Input> */}
                    </div>
                  </div>
                  <button
                    className="bg-inherit  rounded p-2 hover:bg-red-300"
                    onClick={() => handleDeleteLan(i)}
                  >
                    <DeleteIcon />
                  </button>
                </div>
              );
            })}
            <button
              className="bg-inherit rounded mt-2 p-2 hover:bg-lime-500"
              onClick={addObjectLan}
            >
              Нэмэх <AddCircleOutlineRoundedIcon />
            </button>
          </div>
        </div>
        <div className="space-y-3 rounded-md border p-6 bg-slate-100">
          <p className="text-base font-semibold">Ур чадварын мэдээлэл</p>
          <div className="space-y-3">
            {skills.map((e, i) => {
              return (
                <div className="md:flex md:justify-between rounded-md bg-slate-200 border p-6">
                  <div
                    key={i}
                    className="space-y-2 md:space-y-0 md:space-x-2 grid grid-cols-1 md:grid-cols-2"
                  >
                    <div>
                      <p>Төрөл:</p>

                      <Input
                        key={i}
                        name="name"
                        onChange={(e) => handleChangeSki(e, i)}
                        placeholder="төрөл"
                        value={e.name}
                      ></Input>
                    </div>
                    <div>
                      <p>Түвшин:</p>
                      <select
                        key={i}
                        name="level"
                        onChange={(e) => handleChangeSki(e, i)}
                        className="p-2 w-full rounded"
                      >
                        <option value={null}>Сонгоно уу</option>
                        <option value={"Анхан"}>Анхан</option>
                        <option value={"Дунд"}>Дунд</option>
                        <option value={"Ахисан"}>Ахисан</option>
                      </select>
                    </div>
                  </div>
                  <button
                    className="bg-inherit  rounded p-2 hover:bg-red-300"
                    onClick={() => handleDeleteSki(i)}
                  >
                    <DeleteIcon />
                  </button>
                </div>
              );
            })}
            <button
              className="bg-inherit rounded mt-2 p-2 hover:bg-lime-500"
              onClick={addSkillSki}
            >
              Ур чадвар нэмэх <AddCircleOutlineRoundedIcon />
            </button>
          </div>
        </div>
        <div className="space-y-3 rounded-md border p-6 bg-slate-100">
          <p className="text-base font-semibold">
            Та өөрийн нэмэлт CV, Дипломын хуулбар зэргийг нэгтгэн нэг файл
            болгон илгээнэ үү.(PDF болон DOC,DOCX)
          </p>
          <div className="flex space-x-2">
            <IconButton
              color="primary"
              aria-label="upload file"
              component="label"
            >
              <input
                hidden
                type="file"
                id="cv"
                name="cv"
                accept=".pdf,.doc,.docx"
                onChange={(e) => handleFileUpload(e)}
              />
              {/* <input  accept="text/pdf" type="file" /> */}
              <FileUploadIcon />
            </IconButton>
            {cv && (
              <div>
                <image src={cv} alt="pdf" />
              </div>
            )}
          </div>
        </div>

        <div className="flex space-x-5 pt-3">
          {!userData ? (
            <button
              onClick={handleDataCreate}
              className="border border-lime-400  rounded-md w-52 py-2 px-3 hover:bg-lime-400"
            >
              Шинээр анкет хадгалах
            </button>
          ) : (
            <button
              onClick={handleDataSave}
              className="border border-lime-400  rounded-md w-52 py-2 px-3 hover:bg-lime-400"
            >
              Өөрчлөлт хадгалах
            </button>
          )}

          <button
            type="submit"
            onClick={handleDataSave}
            className="border border-lime-400 bg-lime-300  rounded-md w-52 py-2 px-3 hover:bg-lime-400"
          >
            Анкет илгээх
          </button>
        </div>
      </>
    </div>
  );
};
export default FormUser;
