const express = require("express");
const fs = require("fs");
const path = require("path");
const cors = require("cors");
const dotenv = require("dotenv"); //ni config tohirgootoi ajilah library ni dotenv baidag
var rfs = require("rotating-file-stream");
const morgan = require("morgan");
const colors = require("colors");
const fileupload = require("express-fileupload");
const cookieParser = require("cookie-parser");
const rateLimit = require("express-rate-limit");

//mongoose eer dbtei holbogdoh
const connectDB = require("./config/db");
//middleware uudiig oruulj ireh
const errorHandler = require("./middleware/error");
const logger = require("./middleware/logger.js");
//Router oruulj ireh
const careersRoutes = require("./routes/careers.js");
const resumesRoutes = require("./routes/resumes.js");
const resumesJobRoutes = require("./routes/resumejob");
const usersRoutes = require("./routes/users.js");

const app = express();

//Аппын тохиргоог process.env рүү ачаалах
dotenv.config({ path: "./config/config.env" });

connectDB();

app.use(express.static(path.join(__dirname, "public")));
// app.use(express.static(path.join(__dirname, "public")));

//Express rate limit: дуудалтын тоог хягаарлана.
const limiter = rateLimit({
  windows: 15 * 60 * 1000,
  max: 3,
  message: "Хэтэрхий олон удаа хэрэглэгч үүсгэж болохгүй.",
});
// app.use(limiter);

//http huselteer irsen datanii body parser hiij response json Body дахь өгөгдлийг json болгож өгнө.
app.use(express.json());
//Cookie байвал Req.cookie рүү оруулж өгнө.
app.use(cookieParser());
//Өөр өөр домэйнтэй веб аппуудад хандах боломж өгнө.
app.use(cors());
//Сервер рүү upload хийсэн file-тай ажиллана.
app.use(fileupload());

app.use(logger);

// create a rotating write stream
// Morgan logger-ийн тохиргоо
var accessLogStream = rfs.createStream("access.log", {
  interval: "1d", // rotate daily
  path: path.join(__dirname, "log"),
});
app.use(morgan("combined", { stream: accessLogStream }));

//Rest api resourse
app.use("/api/careers", careersRoutes);
app.use("/api/resumes", resumesRoutes);
app.use("/api/users", usersRoutes);
app.use("/api/resumejob", resumesJobRoutes);
//Алдаа үүсэхэд барьж авч алдааны мэдээллийг клиент тал руу автоматаар мэдээлнэ.
app.use(errorHandler);

const server = app.listen(
  process.env.PORT,
  console.log(
    `Express сервэр ${process.env.PORT} порт дээр аслаа...`.underline.cyan
  )
);
process.on("unhandledRejection", (err, promise) => {
  console.log(`aldaa garlaa: ${err.message}`);
  server.close(() => {
    process.exit(1);
  });
});
